#!/usr/bin/env bash
set -e

echo "=== clipper-video-otomatis: Worker Mode ==="

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
cd "$PROJECT_DIR"

if [ -f ".env" ]; then
    export $(grep -v '^#' .env | xargs)
    echo ".env dimuat."
fi

echo "Memulai scheduler worker..."
echo "Entry point: src/scheduler/schedule_manager.py"
echo "Interval cek: 60 detik"
echo ""

python3 -m src.scheduler.schedule_manager
