#!/usr/bin/env bash
set -e

echo "=== clipper-video-otomatis: Install ==="

if ! command -v python3 &>/dev/null; then
    echo "ERROR: python3 tidak ditemukan. Install Python 3.10+ terlebih dahulu."
    exit 1
fi

PYTHON_VERSION=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo "Python versi: $PYTHON_VERSION"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

echo "Project dir: $PROJECT_DIR"
cd "$PROJECT_DIR"

if [ -f ".env.example" ] && [ ! -f ".env" ]; then
    cp .env.example .env
    echo ".env dibuat dari .env.example — edit sesuai kebutuhan."
fi

echo "Menginstall dependency Python..."
python3 -m pip install --upgrade pip --quiet
python3 -m pip install -r requirements.txt

echo "Membuat folder runtime yang diperlukan..."
mkdir -p data logs library/raw library/temp library/shorts library/thumbnails library/metadata
mkdir -p jobs/pending jobs/ready jobs/queued jobs/rendering jobs/done jobs/failed
mkdir -p input/inbox config

echo "Menginisialisasi database..."
python3 scripts/init_db.py

echo ""
echo "=== Instalasi selesai! ==="
echo "Jalankan worker:  ./scripts/run_worker.sh"
echo "Jalankan dev:     ./scripts/run_dev.sh"
