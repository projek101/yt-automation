#!/usr/bin/env bash
set -e

echo "=== clipper-video-otomatis: Development Mode ==="

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
cd "$PROJECT_DIR"

if [ -f ".env" ]; then
    export $(grep -v '^#' .env | xargs)
    echo ".env dimuat."
fi

echo "Memulai Telegram Bot (dev mode)..."
echo "Entry point: src/bot/telegram_bot.py"
echo ""

python3 -m src.bot.telegram_bot
