# clipper-video-otomatis

Backend helper project untuk sistem otomatisasi video shorts berbasis n8n, Telegram, Ollama, FFmpeg, dan YouTube.

---

## Tujuan Sistem

Proyek ini adalah kumpulan helper script Python 3 yang digunakan bersama **n8n** sebagai orkestrator utama.

Sistem ini:
- Menerima input dari file Markdown atau command Telegram
- Menyimpan antrean job ke SQLite
- Memanggil Ollama LLM untuk generate highlight plan, judul, caption, teks layar
- Menjalankan FFmpeg untuk cut, merge, crop, overlay, dan export video shorts
- Menyediakan stub upload ke YouTube
- Mengelola jadwal upload otomatis

Proyek ini **bukan** frontend, bukan web app, dan bukan mobile app.

---

## Cara Install

```bash
chmod +x scripts/install.sh
./scripts/install.sh
```

Atau manual:

```bash
python3 -m pip install -r requirements.txt
python3 scripts/init_db.py
```

---

## Cara Run

### Development

```bash
chmod +x scripts/run_dev.sh
./scripts/run_dev.sh
```

### Worker Queue

```bash
chmod +x scripts/run_worker.sh
./scripts/run_worker.sh
```

---

## Format File Input `.md`

Simpan di `input/jobs.md` atau `input/inbox/`.

```markdown
## JOB 001
URL: https://youtube.com/watch?v=xxxx
SHORTS: 5
SCHEDULE: 06:00,10:00,12:00,16:00,17:00,20:00

PROMPT:
- ambil highlight terbaik
- gabungkan 2 potongan jadi 1 short
- buat portrait 9:16
- tambahkan logo kecil di tengah atas
- buat caption pendek

CAPTION:
Caption opsional di sini.

---

## JOB 002
URL: https://youtube.com/watch?v=yyyy
SHORTS: 3
SCHEDULE: 06:00,12:00,20:00

PROMPT:
- ambil 3 momen lucu
- tiap momen jadi 1 short terpisah

CAPTION:

```

### Aturan Format:
- Setiap job diawali `## JOB NNN`
- `URL:` wajib ada
- `SHORTS:` jumlah short yang diinginkan
- `SCHEDULE:` jam upload (HH:MM) dipisah koma
- `PROMPT:` list instruksi per baris dengan tanda `-`
- `CAPTION:` opsional, bisa kosong
- Job tanpa `PROMPT:` akan ditandai `pending_prompt`
- Pisahkan antar job dengan `---`

---

## Format Output Ollama (Untuk Diparse Sistem)

```
VIDEO_ID: J001
SOURCE_URL: https://youtube.com/watch?v=xxxx
TOTAL_SHORTS: 6

SHORT_01
TITLE: Judul singkat 1
CAPTION: Caption singkat 1
ONSCREEN_TEXT: Teks singkat di video 1
SEGMENTS:
- 00:00:12.200 - 00:00:18.900
- 00:01:05.000 - 00:01:14.300
NOTES: Gabungkan 2 potongan sebagai hook.

SHORT_02
TITLE: Judul singkat 2
CAPTION: Caption singkat 2
ONSCREEN_TEXT: Teks singkat di video 2
SEGMENTS:
- 00:02:10.000 - 00:02:25.000
NOTES: Satu potongan.
```

### Aturan Output:
- 1 short bisa terdiri dari 1 atau lebih segment
- 1 video sumber bisa menghasilkan banyak short
- Segment boleh digabung
- Semua timestamp harus jelas (HH:MM:SS.mmm)
- Format harus konsisten
- Output siap diparse mesin

---

## Format Command Telegram

### Kirim link langsung (prompt menyusul):
```
https://youtube.com/watch?v=xxxx
```
Job akan dibuat dengan status `pending_prompt`.

### Kirim link + prompt langsung:
```
/clip https://youtube.com/watch?v=xxxx
- ambil highlight terbaik
- gabungkan 2 potongan jadi 1 short
- buat portrait 9:16
```

### Kirim batch beberapa link:
```
/clip https://youtube.com/watch?v=xxxx
/clip https://youtube.com/watch?v=yyyy
```

### Tambahkan prompt ke job yang sudah ada:
```
/attach_prompt JOB_001
- instruksi pertama
- instruksi kedua
```

---

## Daftar Command Telegram

| Command | Deskripsi |
|---------|-----------|
| `/help` | Tampilkan daftar command |
| `/template` | Tampilkan template format input |
| `/clip <url> [prompt]` | Buat job baru dari URL YouTube |
| `/status <job_id>` | Cek status job tertentu |
| `/list pending` | Tampilkan semua job pending |
| `/list ready` | Tampilkan semua job ready |
| `/retry <job_id>` | Retry job yang gagal |
| `/attach_prompt <job_id>` | Tambahkan prompt ke job pending_prompt |
| `/pause` | Pause scheduler |
| `/resume` | Resume scheduler |

---

## Status Job

| Status | Keterangan |
|--------|------------|
| `pending_prompt` | Job masuk tapi belum ada prompt |
| `ready` | Job siap diproses (ada URL + prompt) |
| `queued` | Job sudah masuk antrean worker |
| `rendering` | FFmpeg sedang render |
| `ready_to_upload` | Render selesai, menunggu jadwal upload |
| `scheduled` | Upload terjadwal pada jam tertentu |
| `uploaded` | Video berhasil diupload ke YouTube |
| `failed` | Job gagal, bisa di-retry |

---

## Alur Kerja n8n

```
[Input: Telegram / .md file]
         ↓
[Parser: md_parser / telegram_parser]
         ↓
[Queue: insert job ke SQLite]
         ↓
[Ollama: generate highlight plan]
         ↓
[FFmpeg: cut → merge → crop → overlay → export]
         ↓
[Scheduler: cek jam upload]
         ↓
[YouTube Upload Stub]
         ↓
[Status: uploaded / failed]
```

n8n bertugas sebagai orkestrator — memanggil script Python ini via shell node, Execute Command node, atau HTTP request ke webhook lokal.

---

## Troubleshooting

### Database tidak ditemukan
```bash
python3 scripts/init_db.py
```

### FFmpeg tidak terinstal
```bash
sudo apt-get install ffmpeg
# atau
brew install ffmpeg
```

### Ollama tidak bisa diakses
Pastikan Ollama berjalan di `http://localhost:11434`:
```bash
ollama serve
ollama pull phi3:mini
```

### Job stuck di `rendering`
Cek log di `logs/` dan jalankan ulang worker:
```bash
./scripts/run_worker.sh
```

### Upload YouTube gagal
Cek environment variable `YOUTUBE_CLIENT_ID`, `YOUTUBE_CLIENT_SECRET`, dan `YOUTUBE_REFRESH_TOKEN`.

---

## Dependency & Integrasi

| Komponen | Keterangan |
|----------|------------|
| Python 3.10+ | Runtime utama |
| SQLite | Database antrean job (bawaan Python) |
| FFmpeg | Render video, harus terinstal di sistem |
| Ollama | LLM lokal untuk generate plan dan teks |
| python-telegram-bot | Library bot Telegram |
| python-dotenv | Load environment variables dari `.env` |
| requests | HTTP client untuk Ollama |
| schedule | Scheduler antrean upload |

---

## Catatan Integrasi n8n

- Semua modul dapat dipanggil via command line atau import Python
- Gunakan `Execute Command` node di n8n untuk memanggil script
- Gunakan `Read/Write File` node untuk input/output dari `input/` dan `jobs/`
- Webhook n8n bisa trigger `queue_manager.py` langsung
- Status job bisa di-polling via `db.py` dari n8n
