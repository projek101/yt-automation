#!/usr/bin/env python3
"""
n8n helper: ubah status job secara langsung.
Arguments: job_id new_status [notes]

Output: JSON hasil operasi.

Cara panggil dari n8n Execute Command:
  cd /path/to/clipper-project && python3 scripts/n8n/mark_job_status.py JOB_001 queued
  cd /path/to/clipper-project && python3 scripts/n8n/mark_job_status.py JOB_001 failed "Error render gagal"
"""

import sys
import json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

if len(sys.argv) < 3:
    print(json.dumps({"error": "Argument: job_id new_status [notes]"}))
    sys.exit(1)

job_id = sys.argv[1].strip()
new_status = sys.argv[2].strip()
notes = sys.argv[3].strip() if len(sys.argv) > 3 else ""

from src.queue.queue_manager import move_job_status, get_job

job = get_job(job_id)
if not job:
    print(json.dumps({"error": f"Job {job_id} tidak ditemukan"}))
    sys.exit(1)

try:
    ok = move_job_status(job_id, new_status, notes=notes)
    print(json.dumps({
        "job_id": job_id,
        "old_status": job["status"],
        "new_status": new_status,
        "success": ok,
    }))
except ValueError as e:
    print(json.dumps({"error": str(e)}))
    sys.exit(1)
