#!/usr/bin/env python3
"""
n8n helper: ambil semua job dengan status 'ready'.
Output: JSON list job.

Cara panggil dari n8n Execute Command:
  cd /path/to/clipper-project && python3 scripts/n8n/get_ready_jobs.py
"""

import sys
import json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from src.queue.queue_manager import list_jobs_by_status

jobs = list_jobs_by_status("ready")

output = [
    {
        "id": j["id"],
        "source_url": j["source_url"],
        "prompt": j["prompt"],
        "caption": j["caption"],
        "shorts_count": j["shorts_count"],
        "schedule_times": j["schedule_times"],
        "created_at": j["created_at"],
    }
    for j in jobs
]

print(json.dumps(output, ensure_ascii=False))
