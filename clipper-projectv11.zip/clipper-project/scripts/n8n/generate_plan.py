#!/usr/bin/env python3
"""
n8n helper: generate highlight plan via Ollama untuk satu job.
Argument: job_id

Output: JSON hasil operasi.

Cara panggil dari n8n Execute Command:
  cd /path/to/clipper-project && python3 scripts/n8n/generate_plan.py JOB_A1B2C3D4
"""

import sys
import json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

if len(sys.argv) < 2:
    print(json.dumps({"error": "job_id diperlukan sebagai argument pertama"}))
    sys.exit(1)

job_id = sys.argv[1].strip()

from src.queue.queue_manager import get_job, update_job, move_job_status, mark_failed
from src.llm.ollama_client import generate_highlight_plan, OllamaError

job = get_job(job_id)
if not job:
    print(json.dumps({"error": f"Job {job_id} tidak ditemukan"}))
    sys.exit(1)

try:
    plan = generate_highlight_plan(
        source_url=job["source_url"],
        prompt_instructions=job["prompt"],
        shorts_count=job["shorts_count"],
    )
    update_job(job_id, notes=plan)
    move_job_status(job_id, "queued")
    print(json.dumps({
        "job_id": job_id,
        "status": "queued",
        "plan_preview": plan[:200],
        "plan_length": len(plan),
    }, ensure_ascii=False))
except OllamaError as e:
    mark_failed(job_id, str(e))
    print(json.dumps({"error": str(e), "job_id": job_id}))
    sys.exit(1)
except Exception as e:
    mark_failed(job_id, str(e))
    print(json.dumps({"error": str(e), "job_id": job_id}))
    sys.exit(1)
