#!/usr/bin/env python3
"""
n8n helper: cek jumlah job per status di database.
Output: JSON dict {status: count}

Cara panggil dari n8n Execute Command:
  cd /path/to/clipper-project && python3 scripts/n8n/queue_status.py
"""

import sys
import json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from src.queue.queue_manager import count_jobs_by_status, list_all_jobs

counts = count_jobs_by_status()

recent = list_all_jobs()[-5:] if list_all_jobs() else []
recent_simplified = [
    {"id": j["id"], "status": j["status"], "url": j["source_url"][:60]}
    for j in recent
]

print(json.dumps({
    "counts": counts,
    "recent_jobs": recent_simplified,
    "total": sum(counts.values()),
}, ensure_ascii=False))
