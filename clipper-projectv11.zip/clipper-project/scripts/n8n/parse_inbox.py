#!/usr/bin/env python3
"""
n8n helper: parse semua file .md di input/inbox dan masukkan ke SQLite.
Output: JSON list job yang dibuat.

Cara panggil dari n8n Execute Command:
  cd /path/to/clipper-project && python3 scripts/n8n/parse_inbox.py
"""

import sys
import json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from src.parser.md_parser import parse_inbox_dir
from src.queue.queue_manager import insert_job

inbox_path = Path(__file__).resolve().parent.parent.parent / "input" / "inbox"

jobs = parse_inbox_dir(inbox_path)
result = []

for j in jobs:
    try:
        jid = insert_job(
            source_url=j.source_url,
            prompt=j.prompt,
            caption=j.caption,
            schedule_times=j.schedule_times,
            shorts_count=j.shorts_count,
            status=j.status,
            input_source="inbox",
        )
        result.append({"job_id": jid, "status": j.status, "url": j.source_url})
    except Exception as e:
        result.append({"error": str(e), "url": j.source_url})

print(json.dumps(result, ensure_ascii=False))
