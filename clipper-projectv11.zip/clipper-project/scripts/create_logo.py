#!/usr/bin/env python3
"""
create_logo.py — Buat placeholder logo.png sederhana untuk config/.

Menghasilkan file PNG 200x200 piksel berwarna hitam dengan teks "CLIPPER".
File ini bisa diganti dengan logo asli kapan saja.

Memerlukan: Pillow (pip install Pillow)
Jika Pillow tidak tersedia, buat file PNG minimal secara manual.
"""

import sys
import struct
import zlib
from pathlib import Path

OUTPUT_PATH = Path(__file__).parent.parent / "config" / "logo.png"


def _create_minimal_png(width: int, height: int, r: int, g: int, b: int) -> bytes:
    """
    Buat file PNG minimal tanpa dependency eksternal.
    PNG solid satu warna ukuran width x height.
    """
    def chunk(name: bytes, data: bytes) -> bytes:
        c = name + data
        return struct.pack(">I", len(data)) + c + struct.pack(">I", zlib.crc32(c) & 0xFFFFFFFF)

    signature = b"\x89PNG\r\n\x1a\n"
    ihdr_data = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    ihdr = chunk(b"IHDR", ihdr_data)

    raw_row = b"\x00" + bytes([r, g, b] * width)
    raw_data = raw_row * height
    idat = chunk(b"IDAT", zlib.compress(raw_data))
    iend = chunk(b"IEND", b"")

    return signature + ihdr + idat + iend


def create_placeholder_logo(output_path: Path = OUTPUT_PATH) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if output_path.exists():
        print(f"Logo sudah ada di: {output_path}")
        return

    try:
        from PIL import Image, ImageDraw, ImageFont
        img = Image.new("RGB", (200, 200), color=(30, 30, 30))
        draw = ImageDraw.Draw(img)
        try:
            font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 28)
        except Exception:
            font = ImageFont.load_default()
        draw.text((100, 100), "CLIPPER", fill=(255, 255, 255), font=font, anchor="mm")
        img.save(str(output_path), "PNG")
        print(f"Logo (Pillow) dibuat di: {output_path}")

    except ImportError:
        png_bytes = _create_minimal_png(200, 200, 30, 30, 30)
        output_path.write_bytes(png_bytes)
        print(f"Logo placeholder (minimal PNG 200x200) dibuat di: {output_path}")
        print("Untuk logo bergambar, install Pillow dan jalankan ulang, atau ganti file manual.")


if __name__ == "__main__":
    create_placeholder_logo()
