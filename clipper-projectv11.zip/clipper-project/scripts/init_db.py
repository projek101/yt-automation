#!/usr/bin/env python3
"""
init_db.py — Inisialisasi SQLite database untuk clipper-video-otomatis.

Buat tabel jobs dan scheduler_state jika belum ada.
Aman untuk dijalankan berulang kali (idempotent).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.queue.db import create_database, DB_PATH
from src.utils.fs_safe import ensure_dir

print(f"=== init_db: Inisialisasi database ===")
print(f"DB path: {DB_PATH}")

ensure_dir(DB_PATH.parent)
create_database()

print("=== Database berhasil diinisialisasi. ===")
