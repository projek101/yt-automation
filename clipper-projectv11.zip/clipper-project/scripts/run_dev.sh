#!/usr/bin/env bash
set -e

echo "=== clipper-video-otomatis: Development Mode ==="

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
cd "$PROJECT_DIR"

if [ -f ".env" ]; then
    export $(grep -v '^#' .env | xargs -d '\n')
    echo ".env dimuat."
fi

echo "Entry point yang tersedia:"
echo "  [1] Telegram Bot          → python3 -c \"from src.bot.telegram_bot import run_bot; run_bot()\""
echo "  [2] Parse jobs.md manual  → python3 -m src.parser.md_parser input/jobs.md"
echo "  [3] Satu siklus worker    → python3 -m src.scheduler.schedule_manager"
echo "  [4] Cek Ollama health     → python3 -m src.llm.ollama_client"
echo "  [5] Test logger           → python3 -m src.utils.logger"
echo ""

if [ -z "$1" ]; then
    echo "Menjalankan Telegram Bot (default)..."
    python3 -c "
import sys
sys.path.insert(0, '.')
from src.bot.telegram_bot import run_bot
run_bot()
"
elif [ "$1" = "parse" ]; then
    echo "Menjalankan parser pada input/jobs.md..."
    python3 -c "
import sys
sys.path.insert(0, '.')
from src.parser.md_parser import parse_md_file
jobs = parse_md_file('input/jobs.md')
for j in jobs:
    print(f'JOB: {j.job_id} | Status: {j.status} | URL: {j.source_url}')
    print(f'  Shorts: {j.shorts_count} | Schedule: {j.schedule_times}')
    print(f'  Prompt: {j.prompt[:80]}')
    print()
"
elif [ "$1" = "worker" ]; then
    echo "Menjalankan satu siklus worker..."
    python3 -c "
import sys
sys.path.insert(0, '.')
from src.scheduler.schedule_manager import run_upload_cycle
run_upload_cycle()
print('Satu siklus selesai.')
"
elif [ "$1" = "ollama" ]; then
    echo "Cek koneksi Ollama..."
    python3 -c "
import sys
sys.path.insert(0, '.')
from src.llm.ollama_client import check_ollama_health, OLLAMA_BASE_URL, OLLAMA_MODEL
ok = check_ollama_health()
print(f'URL: {OLLAMA_BASE_URL}')
print(f'Model: {OLLAMA_MODEL}')
print(f'Status: {\"OK\" if ok else \"TIDAK BISA DIAKSES\"}')
"
fi
