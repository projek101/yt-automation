#!/usr/bin/env bash
set -e

echo "=== clipper-video-otomatis: Worker Mode ==="

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
cd "$PROJECT_DIR"

if [ -f ".env" ]; then
    export $(grep -v '^#' .env | xargs -d '\n')
    echo ".env dimuat."
fi

echo "Memulai scheduler worker (loop terus-menerus)..."
echo "Entry point: src/scheduler/schedule_manager.py → start_scheduler()"
echo "Tekan Ctrl+C untuk menghentikan."
echo ""

python3 -c "
import sys
sys.path.insert(0, '.')
from src.scheduler.schedule_manager import start_scheduler
start_scheduler(interval_seconds=60)
"
