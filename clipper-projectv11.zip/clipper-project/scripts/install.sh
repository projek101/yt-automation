#!/usr/bin/env bash
set -e

echo "=== clipper-video-otomatis: Install ==="

if ! command -v python3 &>/dev/null; then
    echo "ERROR: python3 tidak ditemukan. Install Python 3.10+ terlebih dahulu."
    exit 1
fi

PYTHON_VERSION=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo "Python versi: $PYTHON_VERSION"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

echo "Project dir: $PROJECT_DIR"
cd "$PROJECT_DIR"

if [ -f ".env.example" ] && [ ! -f ".env" ]; then
    cp .env.example .env
    echo ".env dibuat dari .env.example — edit sesuai kebutuhan Anda."
fi

echo ""
echo "Menginstall dependency Python..."
python3 -m pip install --upgrade pip --quiet
python3 -m pip install -r requirements.txt
echo "Dependency terinstall."

echo ""
echo "Membuat folder runtime yang diperlukan..."
mkdir -p data logs
mkdir -p library/raw library/temp library/shorts library/thumbnails library/metadata
mkdir -p jobs/pending jobs/ready jobs/queued jobs/rendering jobs/done jobs/failed
mkdir -p input/inbox config
mkdir -p scripts/n8n
echo "Folder siap."

echo ""
echo "Menginisialisasi database SQLite..."
python3 scripts/init_db.py
echo "Database siap."

echo ""
echo "Membuat placeholder logo (jika belum ada)..."
python3 scripts/create_logo.py
echo "Logo siap."

echo ""
echo "Membuat skrip n8n executable..."
chmod +x scripts/install.sh scripts/run_dev.sh scripts/run_worker.sh 2>/dev/null || true

echo ""
echo "========================================"
echo "  INSTALASI SELESAI!"
echo "========================================"
echo ""
echo "Langkah selanjutnya:"
echo "  1. Edit .env dan isi konfigurasi Anda"
echo "  2. Pastikan Ollama berjalan: ollama serve"
echo "  3. Taruh video sumber di: library/raw/"
echo "  4. Buat job di: input/jobs.md"
echo "  5. Jalankan worker: ./scripts/run_worker.sh"
echo "  6. Jalankan bot:    ./scripts/run_dev.sh"
echo ""
echo "Dokumentasi lengkap: docs/USER_MANUAL.md"
echo "Quick start:         docs/QUICKSTART.md"
echo "Integrasi n8n:       docs/N8N_INTEGRATION.md"
