# Inbox — clipper-video-otomatis

Folder ini digunakan untuk menaruh file `.md` job secara individual.

## Cara Pakai

1. Buat file `.md` baru di folder ini (misal: `job_baru.md`)
2. Isi dengan format job yang benar (lihat contoh di bawah)
3. Jalankan parser untuk membaca semua file di inbox:

```bash
cd clipper-project
python3 -c "
import sys; sys.path.insert(0, '.')
from src.parser.md_parser import parse_inbox_dir
from src.queue.queue_manager import insert_job

jobs = parse_inbox_dir('input/inbox')
for j in jobs:
    jid = insert_job(
        source_url=j.source_url,
        prompt=j.prompt,
        caption=j.caption,
        schedule_times=j.schedule_times,
        shorts_count=j.shorts_count,
        status=j.status,
        input_source='inbox',
    )
    print(f'Job {jid} ({j.status}) — {j.source_url}')
"
```

## Format File Job

```markdown
## JOB 001
URL: https://youtube.com/watch?v=VIDEO_ID_DI_SINI
SHORTS: 3
SCHEDULE: 06:00,12:00,20:00

PROMPT:
- ambil highlight terbaik dari video
- buat format portrait 9:16
- tambahkan logo di tengah atas
- caption singkat dan menarik

CAPTION:
Teks caption untuk deskripsi video ini.
```

## Catatan

- Satu file bisa berisi lebih dari satu job (pisahkan dengan `---`)
- Job tanpa `PROMPT:` akan ditandai `pending_prompt`
- File yang sudah diproses bisa dipindah atau dihapus
- Gunakan nama file yang deskriptif: `job_topik_tanggal.md`
