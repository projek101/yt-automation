# Input Jobs — clipper-video-otomatis

Format file ini akan dibaca oleh md_parser.py secara otomatis.
Pisahkan setiap job dengan garis `---`.

---

## JOB 001
URL: https://youtube.com/watch?v=contoh-video-id-1
SHORTS: 5
SCHEDULE: 06:00,10:00,12:00,16:00,17:00,20:00

PROMPT:
- ambil highlight terbaik dari video
- gabungkan 2 potongan paling menarik menjadi 1 short
- buat format portrait 9:16
- tambahkan logo kecil di tengah atas
- buat caption pendek dan menarik

CAPTION:
Momen terbaik yang tidak boleh kamu lewatkan!

---

## JOB 002
URL: https://youtube.com/watch?v=contoh-video-id-2
SHORTS: 3
SCHEDULE: 06:00,12:00,20:00

PROMPT:
- ambil 3 momen yang paling informatif
- tiap momen dijadikan 1 short terpisah
- tambahkan teks overlay singkat
- format portrait 9:16

CAPTION:

---

## JOB 003
URL: https://youtube.com/watch?v=contoh-video-id-3
SHORTS: 2
SCHEDULE: 10:00,17:00

