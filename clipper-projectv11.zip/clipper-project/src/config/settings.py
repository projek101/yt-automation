import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(os.getenv("WORK_DIR", ".")).resolve()

TELEGRAM_BOT_TOKEN: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID: str = os.getenv("TELEGRAM_CHAT_ID", "")

OLLAMA_BASE_URL: str = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_MODEL: str = os.getenv("OLLAMA_MODEL", "phi3:mini")

YOUTUBE_CLIENT_ID: str = os.getenv("YOUTUBE_CLIENT_ID", "")
YOUTUBE_CLIENT_SECRET: str = os.getenv("YOUTUBE_CLIENT_SECRET", "")
YOUTUBE_REFRESH_TOKEN: str = os.getenv("YOUTUBE_REFRESH_TOKEN", "")

DB_PATH: Path = Path(os.getenv("DB_PATH", str(BASE_DIR / "data" / "clipper.sqlite"))).resolve()
LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO").upper()

_raw_schedule = os.getenv("SCHEDULE_TIMES", "06:00,10:00,12:00,16:00,17:00,20:00")
SCHEDULE_TIMES: list[str] = [t.strip() for t in _raw_schedule.split(",") if t.strip()]

LIBRARY_DIR: Path = BASE_DIR / "library"
JOBS_DIR: Path = BASE_DIR / "jobs"
INPUT_DIR: Path = BASE_DIR / "input"
LOGS_DIR: Path = BASE_DIR / "logs"
CONFIG_DIR: Path = BASE_DIR / "config"

LOGO_PATH: Path = CONFIG_DIR / "logo.png"

JOB_STATUSES = [
    "pending_prompt",
    "ready",
    "queued",
    "rendering",
    "ready_to_upload",
    "scheduled",
    "uploaded",
    "failed",
]


def validate_settings() -> list[str]:
    warnings: list[str] = []
    if not TELEGRAM_BOT_TOKEN:
        warnings.append("TELEGRAM_BOT_TOKEN is not set — Telegram bot will be disabled.")
    if not OLLAMA_BASE_URL:
        warnings.append("OLLAMA_BASE_URL is not set — defaulting to http://localhost:11434.")
    if not YOUTUBE_CLIENT_ID:
        warnings.append("YOUTUBE_CLIENT_ID is not set — YouTube upload will be stub only.")
    if not DB_PATH.parent.exists():
        warnings.append(f"DB directory does not exist: {DB_PATH.parent}. Run init_db.py.")
    return warnings
