"""
telegram_bot.py — Handler command Telegram dan template balasan.

Modul ini siap dipakai sebagai:
1. Bot standalone (jalankan langsung dengan python-telegram-bot)
2. Modul helper untuk n8n (dipanggil via webhook atau script)

Command yang didukung:
- /help, /template, /clip, /status, /list, /retry, /attach_prompt, /pause, /resume
"""

import asyncio
from src.config.settings import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
from src.parser.telegram_parser import (
    parse_telegram_message,
    get_help_text,
    get_template_text,
)
from src.queue.queue_manager import (
    insert_job,
    get_job,
    update_job,
    move_job_status,
    mark_failed,
    list_jobs_by_status,
    count_jobs_by_status,
)
from src.utils.logger import get_logger

logger = get_logger(__name__)

_scheduler_paused: bool = False


def format_job_summary(job: dict) -> str:
    return (
        f"*ID:* `{job['id']}`\n"
        f"*Status:* {job['status']}\n"
        f"*URL:* {job['source_url']}\n"
        f"*Shorts:* {job['shorts_count']}\n"
        f"*Dibuat:* {job['created_at']}"
    )


def handle_command(text: str, sender_chat_id: str = "") -> list[str]:
    """
    Proses teks pesan Telegram dan kembalikan list respons teks.
    Dapat dipanggil langsung tanpa bot aktif (berguna untuk n8n).
    """
    global _scheduler_paused
    responses: list[str] = []
    commands = parse_telegram_message(text)

    if not commands:
        responses.append("Pesan tidak dikenali. Ketik /help untuk bantuan.")
        return responses

    for cmd in commands:
        if cmd.command == "help":
            responses.append(get_help_text())

        elif cmd.command == "template":
            responses.append(get_template_text())

        elif cmd.command == "clip":
            if not cmd.source_url:
                responses.append("URL YouTube tidak ditemukan. Format: /clip https://youtube.com/watch?v=xxxx")
                continue
            status = "ready" if cmd.prompt else "pending_prompt"
            job_id = insert_job(
                source_url=cmd.source_url,
                prompt=cmd.prompt,
                status=status,
                input_source="telegram",
            )
            if status == "pending_prompt":
                responses.append(
                    f"Job `{job_id}` dibuat dengan status *pending_prompt*.\n"
                    f"Kirimkan prompt dengan:\n`/attach_prompt {job_id}`\n- instruksi 1\n- instruksi 2"
                )
            else:
                responses.append(f"Job `{job_id}` dibuat dengan status *ready*. URL: {cmd.source_url}")

        elif cmd.command == "status":
            if not cmd.job_id:
                responses.append("Format: /status JOB_ID")
                continue
            job = get_job(cmd.job_id)
            if job:
                responses.append(format_job_summary(job))
            else:
                responses.append(f"Job `{cmd.job_id}` tidak ditemukan.")

        elif cmd.command == "list":
            filter_status = cmd.list_filter or "all"
            if filter_status == "all":
                counts = count_jobs_by_status()
                if counts:
                    lines = [f"*Semua Job:*"]
                    for st, cnt in counts.items():
                        lines.append(f"- {st}: {cnt}")
                    responses.append("\n".join(lines))
                else:
                    responses.append("Tidak ada job di database.")
            else:
                try:
                    jobs = list_jobs_by_status(filter_status)
                    if jobs:
                        lines = [f"*Job status '{filter_status}':*"]
                        for j in jobs[:10]:
                            lines.append(f"- `{j['id']}` — {j['source_url'][:50]}")
                        if len(jobs) > 10:
                            lines.append(f"... dan {len(jobs) - 10} lainnya.")
                        responses.append("\n".join(lines))
                    else:
                        responses.append(f"Tidak ada job dengan status '{filter_status}'.")
                except ValueError as e:
                    responses.append(f"Status tidak valid: {e}")

        elif cmd.command == "retry":
            if not cmd.job_id:
                responses.append("Format: /retry JOB_ID")
                continue
            job = get_job(cmd.job_id)
            if not job:
                responses.append(f"Job `{cmd.job_id}` tidak ditemukan.")
            elif job["status"] not in ("failed", "pending_prompt"):
                responses.append(f"Job `{cmd.job_id}` tidak bisa di-retry (status: {job['status']}).")
            else:
                move_job_status(cmd.job_id, "ready", notes="Retry via Telegram")
                responses.append(f"Job `{cmd.job_id}` di-retry dan dikembalikan ke status *ready*.")

        elif cmd.command == "attach_prompt":
            if not cmd.job_id:
                responses.append("Format: /attach_prompt JOB_ID\n- instruksi 1\n- instruksi 2")
                continue
            job = get_job(cmd.job_id)
            if not job:
                responses.append(f"Job `{cmd.job_id}` tidak ditemukan.")
            elif not cmd.prompt:
                responses.append("Prompt kosong. Sertakan instruksi setelah /attach_prompt JOB_ID.")
            else:
                update_job(cmd.job_id, prompt=cmd.prompt, status="ready")
                responses.append(f"Prompt berhasil ditambahkan ke job `{cmd.job_id}`. Status → *ready*.")

        elif cmd.command == "pause":
            _scheduler_paused = True
            responses.append("Scheduler di-*pause*. Upload tidak akan berjalan sampai /resume.")

        elif cmd.command == "resume":
            _scheduler_paused = False
            responses.append("Scheduler di-*resume*. Upload akan berjalan sesuai jadwal.")

        else:
            responses.append(f"Command tidak dikenal: /{cmd.command}")

    return responses


def is_scheduler_paused() -> bool:
    return _scheduler_paused


def run_bot() -> None:
    """
    Jalankan bot Telegram secara async menggunakan python-telegram-bot v20+.
    Memerlukan TELEGRAM_BOT_TOKEN yang valid.
    """
    if not TELEGRAM_BOT_TOKEN:
        logger.error("TELEGRAM_BOT_TOKEN tidak diset. Bot tidak bisa dijalankan.")
        return

    try:
        from telegram import Update
        from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
    except ImportError:
        logger.error("python-telegram-bot belum terinstal. Jalankan: pip install python-telegram-bot")
        return

    async def on_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not update.message or not update.message.text:
            return
        text = update.message.text
        responses = handle_command(text)
        for resp in responses:
            await update.message.reply_text(resp, parse_mode="Markdown")

    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_message))
    app.add_handler(CommandHandler("help", lambda u, c: on_message(u, c)))
    app.add_handler(CommandHandler("clip", lambda u, c: on_message(u, c)))
    app.add_handler(CommandHandler("status", lambda u, c: on_message(u, c)))
    app.add_handler(CommandHandler("list", lambda u, c: on_message(u, c)))
    app.add_handler(CommandHandler("retry", lambda u, c: on_message(u, c)))
    app.add_handler(CommandHandler("attach_prompt", lambda u, c: on_message(u, c)))
    app.add_handler(CommandHandler("pause", lambda u, c: on_message(u, c)))
    app.add_handler(CommandHandler("resume", lambda u, c: on_message(u, c)))
    app.add_handler(CommandHandler("template", lambda u, c: on_message(u, c)))

    logger.info("Bot Telegram berjalan. Ctrl+C untuk berhenti.")
    app.run_polling()


if __name__ == "__main__":
    run_bot()
