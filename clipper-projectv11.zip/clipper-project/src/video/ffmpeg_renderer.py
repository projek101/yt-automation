"""
ffmpeg_renderer.py — Eksekutor render video menggunakan command dari ffmpeg_commands.py.

Fitur:
- render_short(): render satu short dari satu job
- render_job(): render semua short dari satu job
- Berjalan satu per satu (tidak paralel) untuk hemat RAM
- Menyimpan hasil ke library/shorts/
- Menggunakan temp folder sementara
"""

import subprocess
import shutil
import uuid
from pathlib import Path

from src.config.settings import LIBRARY_DIR, LOGO_PATH
from src.video.ffmpeg_commands import build_full_pipeline_commands
from src.utils.logger import get_logger
from src.utils.fs_safe import ensure_dir, safe_move, cleanup_dir

logger = get_logger(__name__)

SHORTS_DIR = LIBRARY_DIR / "shorts"
TEMP_DIR = LIBRARY_DIR / "temp"


def _check_ffmpeg() -> bool:
    """Cek apakah ffmpeg tersedia di sistem."""
    result = subprocess.run(["ffmpeg", "-version"], capture_output=True)
    return result.returncode == 0


def _run_command(cmd: list[str], step_name: str) -> bool:
    """
    Jalankan satu command FFmpeg.
    Kembalikan True jika berhasil, False jika gagal.
    """
    logger.info(f"[render] Menjalankan step '{step_name}': {' '.join(cmd[:6])}...")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        logger.error(f"[render] Step '{step_name}' gagal (exit {result.returncode}):\n{result.stderr[-500:]}")
        return False
    logger.info(f"[render] Step '{step_name}' selesai.")
    return True


def render_short(
    job_id: str,
    short_index: int,
    raw_input_path: str | Path,
    segments: list[tuple[str, str]],
    onscreen_text: str = "",
    use_logo: bool = True,
) -> str | None:
    """
    Render satu video short.

    Args:
        job_id: ID job
        short_index: nomor urut short (1-based)
        raw_input_path: path file video sumber
        segments: list tuple (start_time, end_time) format HH:MM:SS.mmm
        onscreen_text: teks overlay opsional
        use_logo: apakah overlay logo digunakan

    Returns:
        Path ke file output jika berhasil, None jika gagal.
    """
    if not _check_ffmpeg():
        logger.error("[render] ffmpeg tidak ditemukan di sistem. Install terlebih dahulu.")
        return None

    short_id = f"{job_id}_short{short_index:02d}_{uuid.uuid4().hex[:6]}"
    temp_dir = TEMP_DIR / short_id
    output_path = SHORTS_DIR / f"{short_id}.mp4"

    ensure_dir(temp_dir)
    ensure_dir(SHORTS_DIR)

    logo_path = LOGO_PATH if (use_logo and LOGO_PATH.exists()) else None

    try:
        steps = build_full_pipeline_commands(
            raw_input=raw_input_path,
            segments=segments,
            logo_path=logo_path,
            onscreen_text=onscreen_text,
            temp_dir=temp_dir,
            output_path=output_path,
        )

        for step in steps:
            extra = step.get("extra", {})
            if "concat_content" in extra and "concat_list_path" in extra:
                concat_list_path = Path(extra["concat_list_path"])
                concat_list_path.write_text(extra["concat_content"], encoding="utf-8")
                logger.debug(f"[render] Concat list ditulis: {concat_list_path}")

            ok = _run_command(step["cmd"], step["step"])
            if not ok:
                logger.error(f"[render] Render short {short_id} GAGAL di step '{step['step']}'.")
                cleanup_dir(temp_dir)
                return None

        logger.info(f"[render] Short {short_id} selesai → {output_path}")
        cleanup_dir(temp_dir)
        return str(output_path)

    except Exception as e:
        logger.error(f"[render] Exception saat render {short_id}: {e}")
        cleanup_dir(temp_dir)
        return None


def render_job(
    job_id: str,
    raw_input_path: str | Path,
    short_specs: list[dict],
) -> list[str]:
    """
    Render semua short dari satu job.

    short_specs: list dict, masing-masing berisi:
    - segments: list[tuple[str, str]]  # (start, end)
    - onscreen_text: str (opsional)
    - use_logo: bool (opsional, default True)

    Kembalikan list path file output yang berhasil dirender.
    """
    results: list[str] = []
    total = len(short_specs)
    logger.info(f"[render] Mulai render job {job_id} ({total} short).")

    for idx, spec in enumerate(short_specs, start=1):
        logger.info(f"[render] Render short {idx}/{total} untuk job {job_id}...")
        output = render_short(
            job_id=job_id,
            short_index=idx,
            raw_input_path=raw_input_path,
            segments=spec.get("segments", []),
            onscreen_text=spec.get("onscreen_text", ""),
            use_logo=spec.get("use_logo", True),
        )
        if output:
            results.append(output)
        else:
            logger.warning(f"[render] Short {idx} gagal, lanjut ke berikutnya.")

    logger.info(f"[render] Job {job_id} selesai: {len(results)}/{total} short berhasil.")
    return results


if __name__ == "__main__":
    print("ffmpeg tersedia:", _check_ffmpeg())
