"""
ffmpeg_commands.py — Builder command FFmpeg untuk operasi video clipper.

Fungsi:
- build_cut_command(): potong segmen dari video
- build_concat_command(): gabung beberapa segmen menjadi 1
- build_crop_portrait_command(): crop/scale ke format portrait 9:16
- build_overlay_logo_command(): overlay logo di tengah atas
- build_subtitle_command(): tambah subtitle/text overlay
- build_export_command(): export final ke mp4
"""

from pathlib import Path


def _str(p: str | Path) -> str:
    return str(p)


def build_cut_command(
    input_path: str | Path,
    output_path: str | Path,
    start_time: str,
    end_time: str,
) -> list[str]:
    """
    Potong segmen video dari start_time ke end_time.
    Format waktu: HH:MM:SS.mmm

    Contoh: build_cut_command("video.mp4", "cut_01.mp4", "00:01:05.000", "00:01:14.300")
    """
    return [
        "ffmpeg", "-y",
        "-ss", start_time,
        "-to", end_time,
        "-i", _str(input_path),
        "-c", "copy",
        _str(output_path),
    ]


def build_concat_command(
    segment_paths: list[str | Path],
    output_path: str | Path,
    concat_list_path: str | Path,
) -> tuple[str, list[str]]:
    """
    Gabungkan beberapa segmen video menjadi satu.
    Kembalikan (isi file concat list, command ffmpeg).

    Gunakan concat_list_path sebagai file sementara berisi daftar segmen.
    """
    concat_content = "\n".join(f"file '{_str(p)}'" for p in segment_paths)
    cmd = [
        "ffmpeg", "-y",
        "-f", "concat",
        "-safe", "0",
        "-i", _str(concat_list_path),
        "-c", "copy",
        _str(output_path),
    ]
    return concat_content, cmd


def build_crop_portrait_command(
    input_path: str | Path,
    output_path: str | Path,
    target_width: int = 1080,
    target_height: int = 1920,
) -> list[str]:
    """
    Crop dan scale video ke format portrait 9:16.
    Default: 1080x1920 (Full HD portrait).

    Strategi: scale ke lebar target, lalu crop tinggi ke target.
    """
    vf = (
        f"scale={target_width}:-2,"
        f"crop={target_width}:{target_height}"
    )
    return [
        "ffmpeg", "-y",
        "-i", _str(input_path),
        "-vf", vf,
        "-c:v", "libx264",
        "-preset", "fast",
        "-crf", "23",
        "-c:a", "aac",
        "-b:a", "128k",
        _str(output_path),
    ]


def build_overlay_logo_command(
    input_path: str | Path,
    logo_path: str | Path,
    output_path: str | Path,
    logo_scale: int = 80,
    position: str = "center_top",
    margin_top: int = 40,
) -> list[str]:
    """
    Overlay logo kecil di posisi tertentu (default: tengah atas).
    logo_scale: lebar logo dalam pixel.
    margin_top: jarak dari atas frame dalam pixel.
    """
    logo_filter = f"[1:v]scale={logo_scale}:-1[logo]"

    if position == "center_top":
        overlay_pos = f"(main_w-overlay_w)/2:{margin_top}"
    elif position == "top_left":
        overlay_pos = f"{margin_top}:{margin_top}"
    elif position == "top_right":
        overlay_pos = f"main_w-overlay_w-{margin_top}:{margin_top}"
    else:
        overlay_pos = f"(main_w-overlay_w)/2:{margin_top}"

    vf = f"{logo_filter};[0:v][logo]overlay={overlay_pos}"

    return [
        "ffmpeg", "-y",
        "-i", _str(input_path),
        "-i", _str(logo_path),
        "-filter_complex", vf,
        "-c:v", "libx264",
        "-preset", "fast",
        "-crf", "23",
        "-c:a", "copy",
        _str(output_path),
    ]


def build_subtitle_command(
    input_path: str | Path,
    output_path: str | Path,
    text: str,
    font_size: int = 48,
    font_color: str = "white",
    position_y: str = "(h-text_h)/2",
) -> list[str]:
    """
    Tambahkan text overlay (subtitle atau judul) ke video.
    Menggunakan filter drawtext.
    """
    safe_text = text.replace("'", "\\'").replace(":", "\\:")
    drawtext = (
        f"drawtext=text='{safe_text}'"
        f":fontsize={font_size}"
        f":fontcolor={font_color}"
        f":x=(w-text_w)/2"
        f":y={position_y}"
        f":box=1:boxcolor=black@0.5:boxborderw=10"
    )
    return [
        "ffmpeg", "-y",
        "-i", _str(input_path),
        "-vf", drawtext,
        "-c:v", "libx264",
        "-preset", "fast",
        "-crf", "23",
        "-c:a", "copy",
        _str(output_path),
    ]


def build_export_command(
    input_path: str | Path,
    output_path: str | Path,
    crf: int = 23,
    preset: str = "fast",
    audio_bitrate: str = "128k",
) -> list[str]:
    """
    Export final video ke mp4 dengan encoding ulang.
    """
    return [
        "ffmpeg", "-y",
        "-i", _str(input_path),
        "-c:v", "libx264",
        "-preset", preset,
        "-crf", str(crf),
        "-c:a", "aac",
        "-b:a", audio_bitrate,
        "-movflags", "+faststart",
        _str(output_path),
    ]


def build_full_pipeline_commands(
    raw_input: str | Path,
    segments: list[tuple[str, str]],
    logo_path: str | Path | None,
    onscreen_text: str,
    temp_dir: str | Path,
    output_path: str | Path,
) -> list[dict]:
    """
    Buat daftar semua langkah command untuk satu short:
    1. Cut tiap segmen
    2. Concat segmen (jika > 1)
    3. Crop portrait
    4. Overlay logo (opsional)
    5. Tambah text overlay (opsional)
    6. Export final

    Kembalikan list dict dengan kunci:
    - step: nama langkah
    - cmd: list[str] command FFmpeg
    - extra: data tambahan (misalnya isi file concat)
    """
    temp = Path(temp_dir)
    steps = []

    cut_paths = []
    for idx, (start, end) in enumerate(segments):
        cut_out = temp / f"cut_{idx:02d}.mp4"
        cmd = build_cut_command(raw_input, cut_out, start, end)
        steps.append({"step": f"cut_{idx:02d}", "cmd": cmd, "extra": {}})
        cut_paths.append(cut_out)

    if len(cut_paths) == 1:
        concat_out = cut_paths[0]
    else:
        concat_list = temp / "concat_list.txt"
        concat_out = temp / "concat_output.mp4"
        concat_content, cmd = build_concat_command(cut_paths, concat_out, concat_list)
        steps.append({
            "step": "concat",
            "cmd": cmd,
            "extra": {"concat_list_path": str(concat_list), "concat_content": concat_content},
        })

    portrait_out = temp / "portrait.mp4"
    steps.append({
        "step": "crop_portrait",
        "cmd": build_crop_portrait_command(concat_out, portrait_out),
        "extra": {},
    })

    last_out = portrait_out

    if logo_path and Path(logo_path).exists():
        logo_out = temp / "logo_overlay.mp4"
        steps.append({
            "step": "overlay_logo",
            "cmd": build_overlay_logo_command(last_out, logo_path, logo_out),
            "extra": {},
        })
        last_out = logo_out

    if onscreen_text.strip():
        text_out = temp / "text_overlay.mp4"
        steps.append({
            "step": "subtitle",
            "cmd": build_subtitle_command(last_out, text_out, onscreen_text),
            "extra": {},
        })
        last_out = text_out

    steps.append({
        "step": "export",
        "cmd": build_export_command(last_out, output_path),
        "extra": {},
    })

    return steps
