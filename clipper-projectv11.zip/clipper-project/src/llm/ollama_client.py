"""
ollama_client.py — Client HTTP untuk Ollama LLM lokal.

Digunakan untuk:
- generate_highlight_plan(): buat rencana highlight dari video
- generate_title(): buat judul short
- generate_caption(): buat caption
- generate_onscreen_text(): buat teks overlay di video
- chat(): panggil Ollama bebas dengan prompt apapun
"""

import json
import requests
from typing import Any

from src.config.settings import OLLAMA_BASE_URL, OLLAMA_MODEL
from src.utils.logger import get_logger

logger = get_logger(__name__)

DEFAULT_TIMEOUT = 120


class OllamaError(Exception):
    pass


def _build_generate_url(base_url: str) -> str:
    return f"{base_url.rstrip('/')}/api/generate"


def _call_ollama(prompt: str, model: str | None = None, stream: bool = False, timeout: int = DEFAULT_TIMEOUT) -> str:
    """
    Panggil endpoint /api/generate di Ollama.
    Kembalikan teks hasil response.
    Raise OllamaError jika gagal.
    """
    url = _build_generate_url(OLLAMA_BASE_URL)
    payload = {
        "model": model or OLLAMA_MODEL,
        "prompt": prompt,
        "stream": stream,
    }
    try:
        resp = requests.post(url, json=payload, timeout=timeout)
        resp.raise_for_status()
    except requests.exceptions.ConnectionError:
        raise OllamaError(f"Tidak bisa terhubung ke Ollama di {OLLAMA_BASE_URL}. Pastikan Ollama berjalan.")
    except requests.exceptions.Timeout:
        raise OllamaError(f"Request ke Ollama timeout setelah {timeout} detik.")
    except requests.exceptions.HTTPError as e:
        raise OllamaError(f"HTTP error dari Ollama: {e}")

    try:
        data = resp.json()
    except json.JSONDecodeError:
        raise OllamaError("Response dari Ollama bukan JSON yang valid.")

    return data.get("response", "").strip()


def chat(prompt: str, model: str | None = None) -> str:
    """Kirim prompt bebas ke Ollama dan kembalikan teks hasil."""
    logger.debug(f"Mengirim prompt ke Ollama (model={model or OLLAMA_MODEL}): {prompt[:80]}...")
    result = _call_ollama(prompt, model=model)
    logger.debug(f"Hasil Ollama: {result[:80]}...")
    return result


def generate_highlight_plan(
    source_url: str,
    prompt_instructions: str,
    shorts_count: int = 3,
    model: str | None = None,
) -> str:
    """
    Generate rencana highlight untuk video.
    Output diharapkan dalam format terstruktur yang bisa diparse.

    Format output yang diharapkan:
    VIDEO_ID: ...
    SOURCE_URL: ...
    TOTAL_SHORTS: N

    SHORT_01
    TITLE: ...
    CAPTION: ...
    ONSCREEN_TEXT: ...
    SEGMENTS:
    - HH:MM:SS.mmm - HH:MM:SS.mmm
    NOTES: ...
    """
    full_prompt = f"""Kamu adalah asisten editor video.
Diberikan URL video: {source_url}
Instruksi dari pengguna:
{prompt_instructions}

Buatkan rencana {shorts_count} video shorts.
Output HARUS dalam format berikut persis (tanpa penjelasan tambahan):

VIDEO_ID: J001
SOURCE_URL: {source_url}
TOTAL_SHORTS: {shorts_count}

SHORT_01
TITLE: (judul singkat)
CAPTION: (caption singkat)
ONSCREEN_TEXT: (teks singkat untuk overlay di video)
SEGMENTS:
- 00:00:10.000 - 00:00:25.000
NOTES: (catatan opsional)

(ulangi untuk SHORT_02, SHORT_03, dst.)

Aturan:
- Setiap SHORT bisa punya 1 atau lebih SEGMENTS yang akan digabung
- Timestamp format HH:MM:SS.mmm
- Output harus siap diparse mesin, tidak ada penjelasan panjang
"""
    return chat(full_prompt, model=model)


def generate_title(context: str, model: str | None = None) -> str:
    """Generate judul singkat untuk video short."""
    prompt = f"""Buat judul singkat (max 60 karakter) yang menarik untuk video short ini:
Konteks: {context}
Output: hanya judul saja, tanpa tanda kutip, tanpa penjelasan."""
    return chat(prompt, model=model)


def generate_caption(context: str, model: str | None = None) -> str:
    """Generate caption untuk video short."""
    prompt = f"""Buat caption menarik (max 150 karakter) untuk video short ini:
Konteks: {context}
Output: hanya caption saja, bisa dengan hashtag relevan."""
    return chat(prompt, model=model)


def generate_onscreen_text(context: str, model: str | None = None) -> str:
    """Generate teks overlay singkat untuk video short."""
    prompt = f"""Buat teks overlay singkat (max 40 karakter) yang akan ditampilkan di video:
Konteks: {context}
Output: hanya teks pendek saja, tanpa penjelasan."""
    return chat(prompt, model=model)


def check_ollama_health(base_url: str | None = None) -> bool:
    """Cek apakah Ollama dapat diakses."""
    url = (base_url or OLLAMA_BASE_URL).rstrip("/")
    try:
        resp = requests.get(f"{url}/api/tags", timeout=5)
        return resp.status_code == 200
    except Exception:
        return False


if __name__ == "__main__":
    healthy = check_ollama_health()
    print(f"Ollama status: {'OK' if healthy else 'TIDAK BISA DIAKSES'}")
    if healthy:
        result = chat("Halo, siapa kamu?")
        print(f"Hasil: {result}")
