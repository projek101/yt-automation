"""
queue_manager.py — Manajemen job queue di atas SQLite.

Fungsi utama:
- insert_job()
- update_job()
- get_job()
- list_jobs_by_status()
- move_job_status()
- mark_failed()
- mark_done()
"""

import sqlite3
import uuid
from datetime import datetime
from typing import Any

from src.queue.db import get_connection
from src.config.settings import DB_PATH, JOB_STATUSES
from src.utils.logger import get_logger

logger = get_logger(__name__)


def _now() -> str:
    return datetime.utcnow().isoformat(sep=" ", timespec="seconds")


def _validate_status(status: str) -> None:
    if status not in JOB_STATUSES:
        raise ValueError(f"Status tidak valid: '{status}'. Gunakan salah satu dari: {JOB_STATUSES}")


def insert_job(
    source_url: str,
    prompt: str = "",
    caption: str = "",
    schedule_times: list[str] | None = None,
    shorts_count: int = 1,
    status: str = "pending_prompt",
    input_source: str = "unknown",
    notes: str = "",
    job_id: str | None = None,
) -> str:
    """
    Masukkan job baru ke database.
    Kembalikan job_id yang digunakan.
    """
    _validate_status(status)
    jid = job_id or f"JOB_{uuid.uuid4().hex[:8].upper()}"
    schedule_str = ",".join(schedule_times) if schedule_times else ""
    now = _now()

    conn = get_connection()
    try:
        conn.execute(
            """
            INSERT INTO jobs (id, source_url, prompt, caption, schedule_times,
                              shorts_count, status, input_source, created_at, updated_at, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (jid, source_url, prompt, caption, schedule_str,
             shorts_count, status, input_source, now, now, notes),
        )
        conn.commit()
        logger.info(f"Job {jid} dimasukkan dengan status '{status}'.")
    finally:
        conn.close()
    return jid


def update_job(job_id: str, **fields: Any) -> bool:
    """
    Update field tertentu pada job.
    Field yang dapat diupdate: prompt, caption, schedule_times (list→str),
    shorts_count, status, notes, output_path, upload_status.
    """
    if not fields:
        return False

    allowed = {
        "prompt", "caption", "schedule_times", "shorts_count",
        "status", "notes", "output_path", "upload_status", "input_source",
    }
    filtered = {k: v for k, v in fields.items() if k in allowed}

    if "status" in filtered:
        _validate_status(filtered["status"])

    if "schedule_times" in filtered and isinstance(filtered["schedule_times"], list):
        filtered["schedule_times"] = ",".join(filtered["schedule_times"])

    filtered["updated_at"] = _now()
    set_clause = ", ".join(f"{k} = ?" for k in filtered)
    values = list(filtered.values()) + [job_id]

    conn = get_connection()
    try:
        cursor = conn.execute(f"UPDATE jobs SET {set_clause} WHERE id = ?", values)
        conn.commit()
        updated = cursor.rowcount > 0
        if updated:
            logger.info(f"Job {job_id} diupdate: {list(filtered.keys())}")
        else:
            logger.warning(f"Job {job_id} tidak ditemukan untuk update.")
        return updated
    finally:
        conn.close()


def get_job(job_id: str) -> dict | None:
    """Ambil satu job berdasarkan ID."""
    conn = get_connection()
    try:
        row = conn.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
        if row:
            return dict(row)
        return None
    finally:
        conn.close()


def list_jobs_by_status(status: str) -> list[dict]:
    """Ambil semua job berdasarkan status."""
    _validate_status(status)
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT * FROM jobs WHERE status = ? ORDER BY created_at ASC", (status,)
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def list_all_jobs() -> list[dict]:
    """Ambil semua job dari database."""
    conn = get_connection()
    try:
        rows = conn.execute("SELECT * FROM jobs ORDER BY created_at ASC").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def move_job_status(job_id: str, new_status: str, notes: str = "") -> bool:
    """Pindahkan status job ke status baru."""
    _validate_status(new_status)
    fields: dict[str, Any] = {"status": new_status}
    if notes:
        fields["notes"] = notes
    return update_job(job_id, **fields)


def mark_failed(job_id: str, reason: str = "") -> bool:
    """Tandai job sebagai failed dengan catatan alasan."""
    logger.warning(f"Job {job_id} ditandai failed. Alasan: {reason or 'tidak ada'}")
    return update_job(job_id, status="failed", notes=reason)


def mark_done(job_id: str, output_path: str = "") -> bool:
    """Tandai job sebagai uploaded/selesai."""
    logger.info(f"Job {job_id} selesai. Output: {output_path}")
    return update_job(job_id, status="uploaded", output_path=output_path)


def get_next_ready_job() -> dict | None:
    """Ambil job pertama yang berstatus 'ready' (FIFO)."""
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT * FROM jobs WHERE status = 'ready' ORDER BY created_at ASC LIMIT 1"
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def count_jobs_by_status() -> dict[str, int]:
    """Hitung jumlah job per status."""
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT status, COUNT(*) as cnt FROM jobs GROUP BY status"
        ).fetchall()
        return {row["status"]: row["cnt"] for row in rows}
    finally:
        conn.close()


if __name__ == "__main__":
    from src.queue.db import create_database
    create_database()

    jid = insert_job(
        source_url="https://youtube.com/watch?v=test",
        prompt="- ambil highlight",
        shorts_count=3,
        schedule_times=["06:00", "12:00"],
        input_source="test",
    )
    print(f"Job dibuat: {jid}")
    print(f"Detail: {get_job(jid)}")

    move_job_status(jid, "ready")
    print(f"Status setelah move: {get_job(jid)['status']}")

    print(f"Jumlah per status: {count_jobs_by_status()}")
