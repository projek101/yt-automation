"""
db.py — Inisialisasi dan koneksi database SQLite untuk antrean job clipper.
"""

import sqlite3
from pathlib import Path
from src.config.settings import DB_PATH
from src.utils.logger import get_logger

logger = get_logger(__name__)

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS jobs (
    id              TEXT PRIMARY KEY,
    source_url      TEXT NOT NULL,
    prompt          TEXT DEFAULT '',
    caption         TEXT DEFAULT '',
    schedule_times  TEXT DEFAULT '',
    shorts_count    INTEGER DEFAULT 1,
    status          TEXT DEFAULT 'pending_prompt',
    input_source    TEXT DEFAULT 'unknown',
    created_at      TEXT DEFAULT (datetime('now')),
    updated_at      TEXT DEFAULT (datetime('now')),
    notes           TEXT DEFAULT '',
    output_path     TEXT DEFAULT '',
    upload_status   TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS scheduler_state (
    key   TEXT PRIMARY KEY,
    value TEXT
);
"""


def get_connection(db_path: Path | None = None) -> sqlite3.Connection:
    """Buat dan kembalikan koneksi SQLite."""
    path = db_path or DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    return conn


def create_database(db_path: Path | None = None) -> None:
    """Buat tabel database jika belum ada."""
    path = db_path or DB_PATH
    logger.info(f"Inisialisasi database di: {path}")
    conn = get_connection(path)
    try:
        conn.executescript(SCHEMA_SQL)
        conn.commit()
        logger.info("Database berhasil diinisialisasi.")
    finally:
        conn.close()


if __name__ == "__main__":
    create_database()
    print(f"Database siap di: {DB_PATH}")
