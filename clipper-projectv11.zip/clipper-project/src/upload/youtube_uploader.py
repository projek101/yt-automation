"""
youtube_uploader.py — Stub upload video ke YouTube via OAuth2.

Status: STUB — implementasi penuh memerlukan Google OAuth2 dan library google-api-python-client.

TODO:
- Implementasi OAuth2 flow dengan refresh token
- Integrasi google-api-python-client untuk upload resumable
- Handle quota limit YouTube Data API v3
- Tambahkan retry logic untuk upload besar

Fungsi yang tersedia:
- build_metadata(): buat payload metadata video
- validate_upload_payload(): validasi payload sebelum upload
- upload_video(): stub upload ke YouTube
- get_upload_status(): cek status upload
"""

from dataclasses import dataclass, field
from pathlib import Path
from src.config.settings import YOUTUBE_CLIENT_ID, YOUTUBE_CLIENT_SECRET, YOUTUBE_REFRESH_TOKEN
from src.utils.logger import get_logger

logger = get_logger(__name__)


@dataclass
class UploadPayload:
    video_path: str
    title: str
    description: str
    tags: list[str] = field(default_factory=list)
    category_id: str = "22"
    privacy_status: str = "private"
    made_for_kids: bool = False


@dataclass
class UploadResult:
    success: bool
    video_id: str = ""
    video_url: str = ""
    error_message: str = ""
    raw_response: dict = field(default_factory=dict)


def build_metadata(
    title: str,
    description: str,
    tags: list[str] | None = None,
    category_id: str = "22",
    privacy_status: str = "private",
    made_for_kids: bool = False,
) -> dict:
    """
    Buat payload metadata untuk upload YouTube.

    category_id:
    - "1" = Film & Animation
    - "10" = Music
    - "17" = Sports
    - "20" = Gaming
    - "22" = People & Blogs
    - "24" = Entertainment
    - "28" = Science & Technology

    privacy_status: "private" | "public" | "unlisted"
    """
    return {
        "snippet": {
            "title": title[:100],
            "description": description[:5000],
            "tags": (tags or [])[:500],
            "categoryId": category_id,
        },
        "status": {
            "privacyStatus": privacy_status,
            "madeForKids": made_for_kids,
        },
    }


def validate_upload_payload(payload: UploadPayload) -> tuple[bool, list[str]]:
    """
    Validasi payload sebelum upload.
    Kembalikan (is_valid, list_error_messages).
    """
    errors: list[str] = []

    video_path = Path(payload.video_path)
    if not video_path.exists():
        errors.append(f"File video tidak ditemukan: {payload.video_path}")
    elif not video_path.suffix.lower() in {".mp4", ".mov", ".avi", ".mkv"}:
        errors.append(f"Format file tidak didukung: {video_path.suffix}")

    if not payload.title or len(payload.title.strip()) == 0:
        errors.append("Title tidak boleh kosong.")
    elif len(payload.title) > 100:
        errors.append(f"Title terlalu panjang ({len(payload.title)} karakter, max 100).")

    if len(payload.description) > 5000:
        errors.append(f"Description terlalu panjang ({len(payload.description)} karakter, max 5000).")

    if payload.privacy_status not in {"private", "public", "unlisted"}:
        errors.append(f"privacy_status tidak valid: {payload.privacy_status}")

    return (len(errors) == 0), errors


def _check_credentials() -> tuple[bool, str]:
    """Cek apakah credential YouTube tersedia."""
    if not YOUTUBE_CLIENT_ID:
        return False, "YOUTUBE_CLIENT_ID tidak diset."
    if not YOUTUBE_CLIENT_SECRET:
        return False, "YOUTUBE_CLIENT_SECRET tidak diset."
    if not YOUTUBE_REFRESH_TOKEN:
        return False, "YOUTUBE_REFRESH_TOKEN tidak diset."
    return True, ""


def upload_video(payload: UploadPayload) -> UploadResult:
    """
    Upload video ke YouTube.

    STUB: saat ini hanya melakukan validasi dan logging.
    Implementasi penuh memerlukan:
    1. google-api-python-client (`pip install google-api-python-client`)
    2. OAuth2 credentials yang valid
    3. YouTube Data API v3 yang aktif di Google Cloud Console

    TODO: Ganti stub ini dengan implementasi nyata ketika credential tersedia.
    """
    logger.info(f"[youtube] Mulai proses upload: {payload.title}")

    cred_ok, cred_error = _check_credentials()
    if not cred_ok:
        logger.warning(f"[youtube] Credential tidak lengkap: {cred_error}")
        return UploadResult(
            success=False,
            error_message=f"Credential tidak lengkap: {cred_error}",
        )

    is_valid, errors = validate_upload_payload(payload)
    if not is_valid:
        error_str = "; ".join(errors)
        logger.error(f"[youtube] Payload tidak valid: {error_str}")
        return UploadResult(success=False, error_message=error_str)

    logger.info(f"[youtube] STUB MODE — video TIDAK diupload ke YouTube.")
    logger.info(f"[youtube] File: {payload.video_path}")
    logger.info(f"[youtube] Title: {payload.title}")
    logger.info(f"[youtube] Privacy: {payload.privacy_status}")

    # TODO: Implementasi upload nyata:
    # from googleapiclient.discovery import build
    # from googleapiclient.http import MediaFileUpload
    # from google.oauth2.credentials import Credentials
    # creds = Credentials(
    #     token=None,
    #     refresh_token=YOUTUBE_REFRESH_TOKEN,
    #     client_id=YOUTUBE_CLIENT_ID,
    #     client_secret=YOUTUBE_CLIENT_SECRET,
    #     token_uri="https://oauth2.googleapis.com/token",
    # )
    # youtube = build("youtube", "v3", credentials=creds)
    # media = MediaFileUpload(payload.video_path, chunksize=-1, resumable=True)
    # request = youtube.videos().insert(
    #     part="snippet,status",
    #     body=build_metadata(...),
    #     media_body=media,
    # )
    # response = request.execute()
    # video_id = response["id"]
    # return UploadResult(success=True, video_id=video_id, video_url=f"https://youtu.be/{video_id}")

    return UploadResult(
        success=False,
        error_message="STUB: Upload belum diimplementasikan. Lihat TODO di youtube_uploader.py.",
        raw_response={"stub": True, "title": payload.title},
    )


def get_upload_status(video_id: str) -> dict:
    """
    Cek status video yang sudah diupload di YouTube.

    STUB: belum diimplementasikan.
    TODO: Gunakan youtube.videos().list() untuk cek status processing.
    """
    logger.info(f"[youtube] STUB: get_upload_status({video_id}) belum diimplementasikan.")
    return {
        "video_id": video_id,
        "status": "unknown",
        "stub": True,
    }


if __name__ == "__main__":
    payload = UploadPayload(
        video_path="library/shorts/test.mp4",
        title="Test Short Video",
        description="Video test dari clipper.",
        tags=["test", "shorts"],
        privacy_status="private",
    )
    result = upload_video(payload)
    print(f"Hasil upload: success={result.success}, error={result.error_message}")
