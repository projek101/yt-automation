"""
schedule_manager.py — Manajemen jadwal upload otomatis.

Fitur:
- Membaca schedule dari job
- Memilih job berikutnya berdasarkan waktu
- Menandai job sebagai 'scheduled'
- Menahan upload sampai jam yang ditentukan
- Mendukung antrean otomatis 24 jam
- Terintegrasi dengan is_scheduler_paused() dari telegram_bot
"""

import schedule
import time
from datetime import datetime, date
from src.queue.queue_manager import (
    list_jobs_by_status,
    move_job_status,
    update_job,
    mark_done,
    mark_failed,
)
from src.config.settings import SCHEDULE_TIMES
from src.utils.logger import get_logger

logger = get_logger(__name__)

_paused: bool = False


def pause_scheduler() -> None:
    global _paused
    _paused = True
    logger.info("[scheduler] Scheduler di-pause.")


def resume_scheduler() -> None:
    global _paused
    _paused = False
    logger.info("[scheduler] Scheduler di-resume.")


def is_paused() -> bool:
    return _paused


def _parse_time(time_str: str) -> tuple[int, int] | None:
    """Parse string HH:MM menjadi tuple (hour, minute)."""
    try:
        parts = time_str.strip().split(":")
        return int(parts[0]), int(parts[1])
    except Exception:
        return None


def get_next_schedule_time(schedule_times: list[str]) -> str | None:
    """
    Dari daftar jadwal, kembalikan jam berikutnya yang belum lewat hari ini.
    Jika semua sudah lewat, kembalikan jadwal pertama (untuk besok).
    """
    now = datetime.now()
    current_hour = now.hour
    current_minute = now.minute

    parsed = []
    for t in schedule_times:
        parsed_t = _parse_time(t)
        if parsed_t:
            parsed.append((parsed_t, t))

    parsed.sort(key=lambda x: x[0])

    for (h, m), raw in parsed:
        if (h, m) > (current_hour, current_minute):
            return raw

    if parsed:
        return parsed[0][1]

    return None


def should_upload_now(schedule_times_str: str, tolerance_minutes: int = 10) -> bool:
    """
    Cek apakah sekarang adalah waktu upload berdasarkan jadwal.
    Toleransi default: 10 menit setelah jam jadwal.
    """
    if not schedule_times_str:
        return False

    times = [t.strip() for t in schedule_times_str.split(",") if t.strip()]
    now = datetime.now()

    for t in times:
        parsed = _parse_time(t)
        if not parsed:
            continue
        h, m = parsed
        scheduled_dt = now.replace(hour=h, minute=m, second=0, microsecond=0)
        diff_minutes = (now - scheduled_dt).total_seconds() / 60
        if 0 <= diff_minutes <= tolerance_minutes:
            return True

    return False


def pick_next_job_for_upload() -> dict | None:
    """
    Pilih job berikutnya yang siap untuk upload.
    Priority: ready_to_upload → scheduled (jika sudah waktunya)
    Kembalikan job pertama yang ditemukan, atau None.
    """
    jobs_rtu = list_jobs_by_status("ready_to_upload")
    for job in jobs_rtu:
        schedule_str = job.get("schedule_times", "")
        if not schedule_str or should_upload_now(schedule_str):
            return job

    jobs_scheduled = list_jobs_by_status("scheduled")
    for job in jobs_scheduled:
        schedule_str = job.get("schedule_times", "")
        if should_upload_now(schedule_str):
            return job

    return None


def schedule_job_for_upload(job_id: str, schedule_times: list[str]) -> bool:
    """Tandai job sebagai 'scheduled' dengan jadwal tertentu."""
    schedule_str = ",".join(schedule_times)
    ok = update_job(job_id, status="scheduled", schedule_times=schedule_str)
    if ok:
        logger.info(f"[scheduler] Job {job_id} dijadwalkan: {schedule_str}")
    return ok


def run_upload_cycle() -> None:
    """
    Satu siklus cek dan proses upload.
    Dipanggil oleh scheduler setiap menit atau sesuai konfigurasi.
    """
    if _paused:
        logger.debug("[scheduler] Paused, skip cycle.")
        return

    job = pick_next_job_for_upload()
    if not job:
        logger.debug("[scheduler] Tidak ada job yang siap diupload sekarang.")
        return

    job_id = job["id"]
    logger.info(f"[scheduler] Memproses upload job {job_id}...")

    move_job_status(job_id, "queued")

    try:
        from src.upload.youtube_uploader import upload_video, UploadPayload, build_metadata

        output_path = job.get("output_path", "")
        if not output_path:
            logger.error(f"[scheduler] Job {job_id} tidak punya output_path.")
            mark_failed(job_id, "output_path kosong saat jadwal upload.")
            return

        payload = UploadPayload(
            video_path=output_path,
            title=job.get("notes", "Short Video")[:100],
            description=job.get("caption", ""),
            privacy_status="private",
        )
        result = upload_video(payload)

        if result.success:
            mark_done(job_id, output_path=output_path)
            update_job(job_id, upload_status=result.video_url)
            logger.info(f"[scheduler] Job {job_id} berhasil diupload: {result.video_url}")
        else:
            mark_failed(job_id, reason=result.error_message)
            logger.error(f"[scheduler] Job {job_id} gagal upload: {result.error_message}")

    except Exception as e:
        mark_failed(job_id, reason=str(e))
        logger.error(f"[scheduler] Exception saat upload job {job_id}: {e}")


def start_scheduler(interval_seconds: int = 60) -> None:
    """
    Mulai loop scheduler yang cek upload setiap interval_seconds.
    Berjalan terus sampai Ctrl+C.
    """
    logger.info(f"[scheduler] Scheduler dimulai. Interval: {interval_seconds}s. Jadwal: {SCHEDULE_TIMES}")

    schedule.every(interval_seconds).seconds.do(run_upload_cycle)

    try:
        while True:
            schedule.run_pending()
            time.sleep(1)
    except KeyboardInterrupt:
        logger.info("[scheduler] Scheduler dihentikan.")


if __name__ == "__main__":
    run_upload_cycle()
    print("Satu siklus upload selesai.")
