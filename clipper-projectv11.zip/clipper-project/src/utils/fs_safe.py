"""
fs_safe.py — Utility untuk operasi filesystem yang aman.

Fitur:
- ensure_dir(): buat folder jika belum ada
- safe_move(): pindahkan file dengan aman
- safe_rename(): rename file dengan aman
- cleanup_dir(): hapus isi folder temp
- safe_filename(): bersihkan nama file dari karakter tidak aman
- get_unique_path(): buat path unik jika file sudah ada
- list_files(): list file di folder dengan filter ekstensi
"""

import os
import re
import shutil
import uuid
from pathlib import Path
from src.utils.logger import get_logger

logger = get_logger(__name__)


def ensure_dir(path: str | Path) -> Path:
    """Buat folder jika belum ada. Kembalikan Path objek."""
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def safe_move(src: str | Path, dst: str | Path) -> Path | None:
    """
    Pindahkan file dari src ke dst.
    Buat folder tujuan jika belum ada.
    Kembalikan Path tujuan jika berhasil, None jika gagal.
    """
    src_path = Path(src)
    dst_path = Path(dst)

    if not src_path.exists():
        logger.error(f"[fs_safe] File sumber tidak ditemukan: {src_path}")
        return None

    ensure_dir(dst_path.parent)

    try:
        shutil.move(str(src_path), str(dst_path))
        logger.debug(f"[fs_safe] File dipindah: {src_path} → {dst_path}")
        return dst_path
    except Exception as e:
        logger.error(f"[fs_safe] Gagal memindah file {src_path}: {e}")
        return None


def safe_rename(src: str | Path, new_name: str) -> Path | None:
    """
    Rename file dalam folder yang sama.
    Kembalikan Path baru jika berhasil, None jika gagal.
    """
    src_path = Path(src)
    if not src_path.exists():
        logger.error(f"[fs_safe] File tidak ditemukan untuk rename: {src_path}")
        return None

    dst_path = src_path.parent / new_name
    try:
        src_path.rename(dst_path)
        logger.debug(f"[fs_safe] File di-rename: {src_path.name} → {new_name}")
        return dst_path
    except Exception as e:
        logger.error(f"[fs_safe] Gagal rename {src_path}: {e}")
        return None


def cleanup_dir(path: str | Path, remove_dir: bool = False) -> None:
    """
    Hapus semua isi folder temp.
    Jika remove_dir=True, hapus juga folder-nya sendiri.
    """
    p = Path(path)
    if not p.exists():
        return
    try:
        if remove_dir:
            shutil.rmtree(str(p), ignore_errors=True)
            logger.debug(f"[fs_safe] Folder dihapus: {p}")
        else:
            for item in p.iterdir():
                if item.is_file():
                    item.unlink(missing_ok=True)
                elif item.is_dir():
                    shutil.rmtree(str(item), ignore_errors=True)
            logger.debug(f"[fs_safe] Isi folder dibersihkan: {p}")
    except Exception as e:
        logger.warning(f"[fs_safe] Gagal cleanup folder {p}: {e}")


def safe_filename(name: str, max_length: int = 100) -> str:
    """
    Bersihkan string menjadi nama file yang aman.
    Ganti karakter tidak aman dengan underscore.
    """
    clean = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name)
    clean = clean.strip(". ")
    clean = re.sub(r"_+", "_", clean)
    return clean[:max_length] if clean else f"file_{uuid.uuid4().hex[:8]}"


def get_unique_path(path: str | Path) -> Path:
    """
    Jika path sudah ada, tambahkan suffix unik.
    Contoh: output.mp4 → output_a3b4c5.mp4
    """
    p = Path(path)
    if not p.exists():
        return p
    stem = p.stem
    suffix = p.suffix
    parent = p.parent
    unique = parent / f"{stem}_{uuid.uuid4().hex[:6]}{suffix}"
    return unique


def list_files(
    directory: str | Path,
    extensions: list[str] | None = None,
    recursive: bool = False,
) -> list[Path]:
    """
    List file di dalam folder.
    extensions: list ekstensi yang dicari, misal ['.mp4', '.mov']
    recursive: apakah juga cari di subfolder
    """
    d = Path(directory)
    if not d.exists():
        return []

    pattern = "**/*" if recursive else "*"
    all_files = [p for p in d.glob(pattern) if p.is_file()]

    if extensions:
        exts = {e.lower() for e in extensions}
        all_files = [p for p in all_files if p.suffix.lower() in exts]

    return sorted(all_files)


def move_job_file(job_id: str, src_dir: str | Path, dst_dir: str | Path, filename: str) -> Path | None:
    """
    Pindahkan file job dari satu folder status ke folder status lain.
    Berguna untuk pipeline jobs/pending → jobs/ready → jobs/done dst.
    """
    ensure_dir(dst_dir)
    src = Path(src_dir) / filename
    dst = Path(dst_dir) / filename
    return safe_move(src, dst)


if __name__ == "__main__":
    test_dir = Path("/tmp/clipper_fs_test")
    ensure_dir(test_dir)
    test_file = test_dir / "test.txt"
    test_file.write_text("hello", encoding="utf-8")

    moved = safe_move(test_file, test_dir / "renamed.txt")
    print(f"Moved: {moved}")

    print(f"safe_filename: {safe_filename('Hello: World? / Test')}")
    print(f"unique_path: {get_unique_path(test_dir / 'renamed.txt')}")

    cleanup_dir(test_dir, remove_dir=True)
    print("Cleanup done.")
