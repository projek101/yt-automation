"""
logger.py — Konfigurasi logging terpusat untuk seluruh modul clipper.

Fitur:
- Log ke console (stdout)
- Log ke file logs/clipper.log dengan rotasi
- Format rapi dengan timestamp, level, dan nama modul
- Singleton — konfigurasi cukup satu kali
"""

import logging
import logging.handlers
import sys
from pathlib import Path
from src.config import settings

_configured = False
_LOG_FILE = Path(settings.LOGS_DIR) / "clipper.log"


def _setup_root_logger() -> None:
    global _configured
    if _configured:
        return

    level = getattr(logging, settings.LOG_LEVEL, logging.INFO)

    formatter = logging.Formatter(
        fmt="%(asctime)s [%(levelname)-8s] %(name)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    root = logging.getLogger()
    root.setLevel(level)

    if root.handlers:
        root.handlers.clear()

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    root.addHandler(console_handler)

    try:
        _LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.handlers.RotatingFileHandler(
            filename=str(_LOG_FILE),
            maxBytes=5 * 1024 * 1024,
            backupCount=5,
            encoding="utf-8",
        )
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        root.addHandler(file_handler)
    except Exception as e:
        print(f"[logger] Tidak bisa membuat file log: {e}", file=sys.stderr)

    _configured = True


def get_logger(name: str) -> logging.Logger:
    """
    Dapatkan logger untuk modul tertentu.
    Akan otomatis setup root logger jika belum dikonfigurasi.

    Penggunaan:
        from src.utils.logger import get_logger
        logger = get_logger(__name__)
        logger.info("Pesan info")
        logger.error("Pesan error")
    """
    _setup_root_logger()
    return logging.getLogger(name)


if __name__ == "__main__":
    log = get_logger("test_logger")
    log.debug("Ini pesan DEBUG")
    log.info("Ini pesan INFO")
    log.warning("Ini pesan WARNING")
    log.error("Ini pesan ERROR")
    print(f"Log file: {_LOG_FILE}")
