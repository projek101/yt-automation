"""
md_parser.py — Parser untuk file input Markdown format job clipper.

Format yang didukung:

## JOB 001
URL: https://youtube.com/watch?v=xxxx
SHORTS: 5
SCHEDULE: 06:00,10:00,12:00,16:00,17:00,20:00

PROMPT:
- instruksi 1
- instruksi 2

CAPTION:
Teks caption opsional.

---
"""

import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ParsedJob:
    job_id: str
    source_url: str
    shorts_count: int
    schedule_times: list[str]
    prompt: str
    caption: str
    status: str
    raw_block: str


def _extract_field(block: str, key: str) -> str:
    pattern = rf"^{key}:\s*(.+)$"
    match = re.search(pattern, block, re.MULTILINE | re.IGNORECASE)
    if match:
        return match.group(1).strip()
    return ""


def _extract_multiline_section(block: str, key: str) -> str:
    pattern = rf"^{key}:\s*\n((?:(?!^[A-Z]+:|\-\-\-).*\n?)*)"
    match = re.search(pattern, block, re.MULTILINE | re.IGNORECASE)
    if match:
        return match.group(1).strip()
    return ""


def _parse_single_job(block: str) -> ParsedJob | None:
    header_match = re.match(r"##\s+JOB\s+(\S+)", block.strip(), re.IGNORECASE)
    if not header_match:
        return None

    job_id = header_match.group(1).strip()
    source_url = _extract_field(block, "URL")
    if not source_url:
        return None

    shorts_raw = _extract_field(block, "SHORTS")
    try:
        shorts_count = int(shorts_raw)
    except ValueError:
        shorts_count = 1

    schedule_raw = _extract_field(block, "SCHEDULE")
    schedule_times = [t.strip() for t in schedule_raw.split(",") if t.strip()] if schedule_raw else []

    prompt = _extract_multiline_section(block, "PROMPT")
    caption = _extract_multiline_section(block, "CAPTION")

    status = "ready" if prompt else "pending_prompt"

    return ParsedJob(
        job_id=job_id,
        source_url=source_url,
        shorts_count=shorts_count,
        schedule_times=schedule_times,
        prompt=prompt,
        caption=caption,
        status=status,
        raw_block=block.strip(),
    )


def parse_md_string(content: str) -> list[ParsedJob]:
    """Parse string markdown menjadi list ParsedJob."""
    blocks = re.split(r"\n---+\n", content)
    jobs: list[ParsedJob] = []
    for block in blocks:
        block = block.strip()
        if not block:
            continue
        job = _parse_single_job(block)
        if job:
            jobs.append(job)
    return jobs


def parse_md_file(filepath: str | Path) -> list[ParsedJob]:
    """Baca dan parse file markdown job."""
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"File tidak ditemukan: {path}")
    content = path.read_text(encoding="utf-8")
    return parse_md_string(content)


def parse_inbox_dir(inbox_dir: str | Path) -> list[ParsedJob]:
    """Parse semua file .md di folder inbox."""
    inbox = Path(inbox_dir)
    all_jobs: list[ParsedJob] = []
    for md_file in sorted(inbox.glob("*.md")):
        try:
            jobs = parse_md_file(md_file)
            all_jobs.extend(jobs)
        except Exception as e:
            print(f"[md_parser] Gagal parse {md_file}: {e}")
    return all_jobs


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python md_parser.py <file.md>")
        sys.exit(1)

    jobs = parse_md_file(sys.argv[1])
    for j in jobs:
        print(f"JOB: {j.job_id} | URL: {j.source_url} | Status: {j.status} | Shorts: {j.shorts_count}")
        print(f"  Schedule: {j.schedule_times}")
        print(f"  Prompt: {j.prompt[:80]}...")
        print()
