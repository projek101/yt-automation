"""
telegram_parser.py — Parser command dan pesan dari Telegram.

Command yang didukung:
- /help
- /template
- /clip <url> [prompt]
- /status <job_id>
- /list pending | ready
- /retry <job_id>
- /attach_prompt <job_id>
- /pause
- /resume

Format pesan juga mendukung:
- URL saja (tanpa command) → pending_prompt
- /clip dengan URL + prompt langsung
- Batch beberapa /clip sekaligus
"""

import re
from dataclasses import dataclass, field


YOUTUBE_URL_PATTERN = re.compile(
    r"https?://(www\.)?(youtube\.com/watch\?v=|youtu\.be/)[\w\-]+"
)

SUPPORTED_COMMANDS = [
    "/help",
    "/template",
    "/clip",
    "/status",
    "/list",
    "/retry",
    "/attach_prompt",
    "/pause",
    "/resume",
]

HELP_TEXT = """
*Clipper Video Otomatis — Command Telegram*

/help — Tampilkan daftar command
/template — Tampilkan template format input
/clip <url> [prompt] — Buat job baru dari URL YouTube
/status <job_id> — Cek status job tertentu
/list pending — Tampilkan semua job pending
/list ready — Tampilkan semua job siap diproses
/retry <job_id> — Retry job yang gagal
/attach_prompt <job_id> — Tambahkan prompt ke job pending
/pause — Pause scheduler upload
/resume — Resume scheduler upload
""".strip()

TEMPLATE_TEXT = """
*Template Format Job:*

```
## JOB 001
URL: https://youtube.com/watch?v=xxxx
SHORTS: 5
SCHEDULE: 06:00,10:00,12:00,16:00,17:00,20:00

PROMPT:
- ambil highlight terbaik
- gabungkan 2 potongan jadi 1 short
- buat portrait 9:16
- tambahkan logo di tengah atas
- buat caption pendek

CAPTION:
Caption opsional di sini.
```
""".strip()


@dataclass
class TelegramCommand:
    command: str
    job_id: str = ""
    source_url: str = ""
    prompt: str = ""
    list_filter: str = ""
    raw_text: str = ""


def _extract_url(text: str) -> str:
    match = YOUTUBE_URL_PATTERN.search(text)
    if match:
        return match.group(0)
    return ""


def _extract_prompt_lines(text: str) -> str:
    lines = text.splitlines()
    prompt_lines = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("-"):
            prompt_lines.append(stripped)
    return "\n".join(prompt_lines)


def parse_telegram_message(text: str) -> list[TelegramCommand]:
    """
    Parse satu pesan Telegram menjadi list TelegramCommand.
    Mendukung multi-command dalam satu pesan (batch).
    """
    text = text.strip()
    commands: list[TelegramCommand] = []

    if not text:
        return commands

    url_only = _extract_url(text)
    if url_only and not text.startswith("/"):
        commands.append(TelegramCommand(
            command="clip",
            source_url=url_only,
            prompt="",
            raw_text=text,
        ))
        return commands

    lines = text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if not line:
            i += 1
            continue

        if line.startswith("/help"):
            commands.append(TelegramCommand(command="help", raw_text=line))

        elif line.startswith("/template"):
            commands.append(TelegramCommand(command="template", raw_text=line))

        elif line.startswith("/pause"):
            commands.append(TelegramCommand(command="pause", raw_text=line))

        elif line.startswith("/resume"):
            commands.append(TelegramCommand(command="resume", raw_text=line))

        elif line.startswith("/status"):
            parts = line.split(maxsplit=1)
            job_id = parts[1].strip() if len(parts) > 1 else ""
            commands.append(TelegramCommand(command="status", job_id=job_id, raw_text=line))

        elif line.startswith("/retry"):
            parts = line.split(maxsplit=1)
            job_id = parts[1].strip() if len(parts) > 1 else ""
            commands.append(TelegramCommand(command="retry", job_id=job_id, raw_text=line))

        elif line.startswith("/list"):
            parts = line.split(maxsplit=1)
            list_filter = parts[1].strip().lower() if len(parts) > 1 else "all"
            commands.append(TelegramCommand(command="list", list_filter=list_filter, raw_text=line))

        elif line.startswith("/attach_prompt"):
            parts = line.split(maxsplit=1)
            job_id = parts[1].strip() if len(parts) > 1 else ""
            prompt_lines = []
            i += 1
            while i < len(lines):
                next_line = lines[i].strip()
                if next_line.startswith("/") or not next_line:
                    break
                prompt_lines.append(next_line)
                i += 1
            prompt = "\n".join(prompt_lines)
            commands.append(TelegramCommand(
                command="attach_prompt",
                job_id=job_id,
                prompt=prompt,
                raw_text=line,
            ))
            continue

        elif line.startswith("/clip"):
            rest = line[5:].strip()
            source_url = _extract_url(rest)
            prompt_lines: list[str] = []
            i += 1
            while i < len(lines):
                next_line = lines[i].strip()
                if next_line.startswith("/"):
                    break
                if next_line:
                    prompt_lines.append(next_line)
                i += 1
            prompt = "\n".join(prompt_lines)
            commands.append(TelegramCommand(
                command="clip",
                source_url=source_url,
                prompt=prompt,
                raw_text=line,
            ))
            continue

        i += 1

    return commands


def get_help_text() -> str:
    return HELP_TEXT


def get_template_text() -> str:
    return TEMPLATE_TEXT


if __name__ == "__main__":
    test_messages = [
        "/help",
        "/clip https://youtube.com/watch?v=xxxx\n- ambil highlight\n- buat portrait 9:16",
        "https://youtube.com/watch?v=yyyy",
        "/list pending",
        "/status JOB_001",
        "/attach_prompt JOB_002\n- instruksi pertama\n- instruksi kedua",
        "/retry JOB_003",
    ]

    for msg in test_messages:
        print(f"Input: {repr(msg[:60])}")
        result = parse_telegram_message(msg)
        for cmd in result:
            print(f"  → command={cmd.command} job_id={cmd.job_id} url={cmd.source_url}")
        print()
