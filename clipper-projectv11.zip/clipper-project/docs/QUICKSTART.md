# Quick Start — clipper-video-otomatis

## 5 Menit Pertama

### Langkah 1: Install

```bash
cd clipper-project
chmod +x scripts/*.sh
./scripts/install.sh
```

### Langkah 2: Isi .env

```bash
nano .env
```

Minimal yang perlu diisi:
```
TELEGRAM_BOT_TOKEN=token_dari_botfather
TELEGRAM_CHAT_ID=chat_id_kamu
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=phi3:mini
```

### Langkah 3: Pastikan Ollama Berjalan

```bash
ollama serve &
ollama pull phi3:mini
```

### Langkah 4: Buat Job Pertama

Edit `input/jobs.md`:

```markdown
## JOB 001
URL: https://youtube.com/watch?v=VIDEO_ID_KAMU
SHORTS: 3
SCHEDULE: 06:00,12:00,20:00

PROMPT:
- ambil 3 momen paling menarik
- buat format portrait 9:16
- tambahkan logo di tengah atas
- caption singkat

CAPTION:
Jangan lewatkan ini!
```

### Langkah 5: Parse dan Masukkan ke Queue

```bash
python3 scripts/n8n/parse_inbox.py
# atau
python3 -c "
import sys; sys.path.insert(0, '.')
from src.parser.md_parser import parse_md_file
from src.queue.queue_manager import insert_job

for j in parse_md_file('input/jobs.md'):
    jid = insert_job(source_url=j.source_url, prompt=j.prompt,
                     caption=j.caption, schedule_times=j.schedule_times,
                     shorts_count=j.shorts_count, status=j.status,
                     input_source='jobs.md')
    print(f'Job: {jid} [{j.status}]')
"
```

### Langkah 6: Cek Status Queue

```bash
python3 scripts/n8n/queue_status.py
```

### Langkah 7: Jalankan Telegram Bot (Terminal 1)

```bash
./scripts/run_dev.sh
```

### Langkah 8: Jalankan Worker (Terminal 2)

```bash
./scripts/run_worker.sh
```

---

## Struktur Folder Setelah Setup

```
clipper-project/
├── .env                 ← Konfigurasi kamu (sudah diisi)
├── data/
│   └── clipper.sqlite   ← Database job queue
├── input/
│   ├── jobs.md          ← File input batch
│   └── inbox/           ← Taruh file .md individual di sini
├── library/
│   ├── raw/             ← Taruh video sumber di sini
│   ├── shorts/          ← Hasil render shorts
│   └── temp/            ← File sementara (auto-cleanup)
├── logs/
│   └── clipper.log      ← Log semua aktivitas
└── config/
    ├── settings.json    ← Konfigurasi default
    └── logo.png         ← Logo overlay (ganti dengan logo kamu)
```

---

## Ganti Logo

Ganti `config/logo.png` dengan logo kamu sendiri:
- Format: PNG dengan background transparan
- Ukuran: 80-150px lebar (akan di-scale otomatis)
- Posisi default: tengah atas video

---

## Lanjut Baca

- [USER_MANUAL.md](USER_MANUAL.md) — Panduan lengkap semua fitur
- [PROJECT_OVERVIEW.md](PROJECT_OVERVIEW.md) — Penjelasan arsitektur
- [N8N_INTEGRATION.md](N8N_INTEGRATION.md) — Cara integrasi dengan n8n
