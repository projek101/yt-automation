# User Manual — clipper-video-otomatis

## Daftar Isi

1. [Persiapan Awal](#1-persiapan-awal)
2. [Konfigurasi .env](#2-konfigurasi-env)
3. [Cara Membuat Job](#3-cara-membuat-job)
4. [Cara Menggunakan Telegram Bot](#4-cara-menggunakan-telegram-bot)
5. [Mengelola Job via Database](#5-mengelola-job-via-database)
6. [Menjalankan Render Video](#6-menjalankan-render-video)
7. [Menjadwalkan Upload YouTube](#7-menjadwalkan-upload-youtube)
8. [Monitoring dan Log](#8-monitoring-dan-log)
9. [Troubleshooting Umum](#9-troubleshooting-umum)
10. [Referensi Command](#10-referensi-command)

---

## 1. Persiapan Awal

### A. Install Dependencies

```bash
cd clipper-project
chmod +x scripts/install.sh
./scripts/install.sh
```

Script ini akan:
- Menginstall semua library Python yang dibutuhkan
- Membuat folder runtime (`data/`, `logs/`, `library/`, dll.)
- Menginisialisasi database SQLite
- Membuat file `.env` dari template

### B. Install FFmpeg

FFmpeg harus terinstal di sistem (BUKAN via pip):

**Ubuntu/Debian:**
```bash
sudo apt-get update && sudo apt-get install -y ffmpeg
```

**macOS:**
```bash
brew install ffmpeg
```

**Cek instalasi:**
```bash
ffmpeg -version
```

### C. Install dan Jalankan Ollama

```bash
# Install Ollama (lihat https://ollama.com)
curl -fsSL https://ollama.com/install.sh | sh

# Download model (pilih salah satu)
ollama pull phi3:mini     # Ringan, cepat
ollama pull llama3        # Lebih pintar
ollama pull mistral       # Alternatif

# Pastikan Ollama berjalan
ollama serve
```

### D. Setup Telegram Bot (Opsional tapi Disarankan)

1. Chat dengan `@BotFather` di Telegram
2. Ketik `/newbot` dan ikuti instruksinya
3. Salin token yang diberikan
4. Dapatkan Chat ID dengan chat ke `@userinfobot`
5. Isi `TELEGRAM_BOT_TOKEN` dan `TELEGRAM_CHAT_ID` di `.env`

---

## 2. Konfigurasi .env

Edit file `.env` di root project:

```bash
nano clipper-project/.env
```

### Penjelasan Setiap Variable

| Variable | Contoh Nilai | Keterangan |
|----------|-------------|------------|
| `TELEGRAM_BOT_TOKEN` | `123456:ABC...` | Token dari @BotFather |
| `TELEGRAM_CHAT_ID` | `123456789` | Chat ID untuk notifikasi |
| `OLLAMA_BASE_URL` | `http://localhost:11434` | URL Ollama lokal |
| `OLLAMA_MODEL` | `phi3:mini` | Model yang digunakan |
| `YOUTUBE_CLIENT_ID` | `xxx.apps.googleusercontent.com` | Google OAuth2 Client ID |
| `YOUTUBE_CLIENT_SECRET` | `GOCSPX-...` | Google OAuth2 Secret |
| `YOUTUBE_REFRESH_TOKEN` | `1//...` | Refresh token YouTube |
| `WORK_DIR` | `.` | Direktori kerja (biasanya `.`) |
| `DB_PATH` | `./data/clipper.sqlite` | Lokasi database |
| `LOG_LEVEL` | `INFO` | Level logging |
| `SCHEDULE_TIMES` | `06:00,10:00,20:00` | Jam upload otomatis |

---

## 3. Cara Membuat Job

Ada tiga cara membuat job:

### Cara A: File Markdown (`input/jobs.md`)

Edit file `input/jobs.md` dan tambahkan job:

```markdown
## JOB 001
URL: https://youtube.com/watch?v=VIDEO_ID
SHORTS: 5
SCHEDULE: 06:00,10:00,12:00,16:00,20:00

PROMPT:
- ambil highlight terbaik dari video
- gabungkan 2 potongan paling seru jadi 1 short
- buat format portrait 9:16
- tambahkan logo di tengah atas
- buat caption singkat dan menarik

CAPTION:
Jangan lewatkan momen epic ini!
```

Lalu parse dan masukkan ke database:

```bash
python3 -c "
import sys; sys.path.insert(0, '.')
from src.parser.md_parser import parse_md_file
from src.queue.queue_manager import insert_job

jobs = parse_md_file('input/jobs.md')
for j in jobs:
    jid = insert_job(
        source_url=j.source_url,
        prompt=j.prompt,
        caption=j.caption,
        schedule_times=j.schedule_times,
        shorts_count=j.shorts_count,
        status=j.status,
        input_source='jobs.md',
    )
    print(f'Dibuat: {jid} [{j.status}]')
"
```

### Cara B: Telegram Command

Kirim ke bot Telegram:

```
/clip https://youtube.com/watch?v=VIDEO_ID
- ambil highlight terbaik
- gabungkan 2 potongan jadi 1 short
- buat portrait 9:16
- tambahkan logo di tengah atas
```

### Cara C: File di Inbox (`input/inbox/`)

Buat file `.md` baru di folder `input/inbox/`:

```bash
cat > clipper-project/input/inbox/job_hari_ini.md << 'EOF'
## JOB HARI INI
URL: https://youtube.com/watch?v=VIDEO_ID
SHORTS: 3
SCHEDULE: 06:00,12:00,20:00

PROMPT:
- ambil 3 momen lucu
- tiap momen jadi 1 short terpisah

CAPTION:
LOL momen ini 😂
EOF
```

---

## 4. Cara Menggunakan Telegram Bot

### Menjalankan Bot

```bash
cd clipper-project
./scripts/run_dev.sh
```

Atau langsung:
```bash
python3 -c "
import sys; sys.path.insert(0, '.')
from src.bot.telegram_bot import run_bot
run_bot()
"
```

### Daftar Command

#### `/help`
Tampilkan semua command yang tersedia.

#### `/template`
Tampilkan template format input job.

#### `/clip <url> [prompt]`
Buat job baru dari URL YouTube.

**Contoh — dengan prompt langsung:**
```
/clip https://youtube.com/watch?v=VIDEO_ID
- ambil highlight terbaik
- buat portrait 9:16
- tambahkan logo
```

**Contoh — hanya URL (prompt menyusul):**
```
/clip https://youtube.com/watch?v=VIDEO_ID
```
Job akan dibuat dengan status `pending_prompt`. Kirimkan prompt nanti dengan `/attach_prompt`.

#### `/status <job_id>`
Cek status satu job:
```
/status JOB_A1B2C3D4
```

#### `/list pending`
Tampilkan semua job yang menunggu prompt.

#### `/list ready`
Tampilkan semua job yang siap diproses.

#### `/retry <job_id>`
Retry job yang gagal:
```
/retry JOB_A1B2C3D4
```

#### `/attach_prompt <job_id>`
Tambahkan prompt ke job `pending_prompt`:
```
/attach_prompt JOB_A1B2C3D4
- ambil highlight terbaik
- buat portrait 9:16
- tambahkan teks overlay
```

#### `/pause`
Pause scheduler — upload tidak akan berjalan.

#### `/resume`
Resume scheduler — upload kembali berjalan.

---

## 5. Mengelola Job via Database

Interaksi langsung dengan database via Python:

```bash
python3 -c "
import sys; sys.path.insert(0, '.')
from src.queue.queue_manager import *

# Lihat semua job ready
jobs = list_jobs_by_status('ready')
for j in jobs:
    print(j['id'], j['source_url'])

# Cek satu job
job = get_job('JOB_A1B2C3D4')
print(job)

# Ubah status
move_job_status('JOB_A1B2C3D4', 'queued')

# Tandai gagal
mark_failed('JOB_A1B2C3D4', 'Error: file tidak ditemukan')

# Tandai selesai
mark_done('JOB_A1B2C3D4', output_path='library/shorts/hasil.mp4')

# Hitung per status
print(count_jobs_by_status())
"
```

---

## 6. Menjalankan Render Video

### Prasyarat
- Video sumber sudah didownload ke `library/raw/`
- Ollama sudah menghasilkan rencana highlight (format SHORT_01, SHORT_02, dst.)
- Job berstatus `queued` atau `ready`

### Render Manual Satu Short

```bash
python3 -c "
import sys; sys.path.insert(0, '.')
from src.video.ffmpeg_renderer import render_short

output = render_short(
    job_id='JOB_001',
    short_index=1,
    raw_input_path='library/raw/video_sumber.mp4',
    segments=[
        ('00:00:12.200', '00:00:18.900'),
        ('00:01:05.000', '00:01:14.300'),
    ],
    onscreen_text='Momen Epic!',
    use_logo=True,
)
print('Output:', output)
"
```

### Render Semua Short dari Satu Job

```bash
python3 -c "
import sys; sys.path.insert(0, '.')
from src.video.ffmpeg_renderer import render_job

results = render_job(
    job_id='JOB_001',
    raw_input_path='library/raw/video_sumber.mp4',
    short_specs=[
        {
            'segments': [('00:00:12.200', '00:00:18.900'), ('00:01:05.000', '00:01:14.300')],
            'onscreen_text': 'Momen 1',
            'use_logo': True,
        },
        {
            'segments': [('00:02:10.000', '00:02:25.000')],
            'onscreen_text': 'Momen 2',
            'use_logo': True,
        },
    ],
)
print('Hasil:', results)
"
```

---

## 7. Menjadwalkan Upload YouTube

### Setup OAuth2 YouTube (Sekali Saja)

1. Buka [Google Cloud Console](https://console.cloud.google.com)
2. Buat project baru atau pilih yang ada
3. Aktifkan "YouTube Data API v3"
4. Buat credential "OAuth 2.0 Client ID" (tipe: Desktop App)
5. Download file JSON credential
6. Jalankan flow OAuth2 untuk dapatkan refresh token:

```bash
python3 -c "
# TODO: Implementasikan OAuth2 flow
# Lihat: https://developers.google.com/youtube/v3/guides/authentication
# Setelah mendapat refresh token, isi YOUTUBE_REFRESH_TOKEN di .env
print('Lihat docs/N8N_INTEGRATION.md untuk panduan OAuth2 YouTube')
"
```

7. Isi nilai di `.env`:
```
YOUTUBE_CLIENT_ID=xxx.apps.googleusercontent.com
YOUTUBE_CLIENT_SECRET=GOCSPX-...
YOUTUBE_REFRESH_TOKEN=1//...
```

### Menjalankan Scheduler Worker

```bash
cd clipper-project
./scripts/run_worker.sh
```

Scheduler akan cek setiap 60 detik apakah ada job yang siap diupload berdasarkan jadwal di `SCHEDULE_TIMES`.

---

## 8. Monitoring dan Log

### Melihat Log Real-time

```bash
tail -f clipper-project/logs/clipper.log
```

### Melihat Ringkasan Status

```bash
python3 -c "
import sys; sys.path.insert(0, '.')
from src.queue.queue_manager import count_jobs_by_status
counts = count_jobs_by_status()
for status, count in sorted(counts.items()):
    print(f'{status:20s}: {count}')
"
```

### Melihat Job Terbaru

```bash
python3 -c "
import sys; sys.path.insert(0, '.')
from src.queue.queue_manager import list_all_jobs
jobs = list_all_jobs()
for j in jobs[-10:]:
    print(f\"{j['id']} [{j['status']:15s}] {j['source_url'][:50]}\")
"
```

---

## 9. Troubleshooting Umum

### "ModuleNotFoundError: No module named 'src'"
Pastikan kamu berada di folder `clipper-project/` saat menjalankan perintah:
```bash
cd clipper-project
python3 -c "import sys; sys.path.insert(0, '.'); from src.config import settings"
```

### "Database tidak ditemukan"
Inisialisasi ulang database:
```bash
python3 scripts/init_db.py
```

### "ffmpeg: command not found"
Install FFmpeg:
```bash
sudo apt-get install ffmpeg    # Linux
brew install ffmpeg            # macOS
```

### "Tidak bisa terhubung ke Ollama"
Pastikan Ollama berjalan:
```bash
ollama serve &
ollama list    # cek model yang tersedia
```

### "TELEGRAM_BOT_TOKEN is not set"
Edit `.env` dan isi nilai token.

### Job stuck di "rendering"
Cek log untuk error FFmpeg:
```bash
grep -i "error\|gagal" clipper-project/logs/clipper.log | tail -20
```

---

## 10. Referensi Command

### Script Shell

| Command | Fungsi |
|---------|--------|
| `./scripts/install.sh` | Install semua dependency |
| `./scripts/run_dev.sh` | Jalankan bot Telegram |
| `./scripts/run_dev.sh parse` | Parse input/jobs.md |
| `./scripts/run_dev.sh worker` | Satu siklus worker |
| `./scripts/run_dev.sh ollama` | Cek koneksi Ollama |
| `./scripts/run_worker.sh` | Jalankan scheduler loop |
| `python3 scripts/init_db.py` | Init/reset database |
| `python3 scripts/create_logo.py` | Buat placeholder logo |

### Telegram Commands

| Command | Fungsi |
|---------|--------|
| `/help` | Tampilkan bantuan |
| `/template` | Tampilkan template format |
| `/clip <url>` | Buat job baru |
| `/status <id>` | Cek status job |
| `/list pending` | Daftar job pending |
| `/list ready` | Daftar job siap |
| `/retry <id>` | Retry job gagal |
| `/attach_prompt <id>` | Tambah prompt ke job |
| `/pause` | Pause upload scheduler |
| `/resume` | Resume upload scheduler |
