# Panduan Integrasi n8n — clipper-video-otomatis

## Gambaran Umum

n8n berperan sebagai **orkestrator utama** dalam sistem ini. Project clipper-video-otomatis hanya menyediakan "modul" yang bisa dipanggil oleh n8n kapan saja dan dalam urutan apapun.

n8n tidak perlu tahu cara kerja internal setiap modul — cukup tahu bagaimana memanggilnya.

---

## Cara n8n Memanggil Script Python

### Metode 1: Execute Command Node

Di n8n, gunakan node **"Execute Command"** untuk memanggil script Python:

```bash
cd /path/to/clipper-project && python3 -c "
import sys; sys.path.insert(0, '.')
from src.parser.md_parser import parse_md_file
from src.queue.queue_manager import insert_job
import json

jobs = parse_md_file('input/jobs.md')
result = []
for j in jobs:
    jid = insert_job(
        source_url=j.source_url,
        prompt=j.prompt,
        caption=j.caption,
        schedule_times=j.schedule_times,
        shorts_count=j.shorts_count,
        status=j.status,
        input_source='n8n',
    )
    result.append({'id': jid, 'status': j.status, 'url': j.source_url})

print(json.dumps(result))
"
```

Output JSON dari perintah ini bisa langsung diparse oleh n8n di node berikutnya.

### Metode 2: Script File

Buat script Python yang bisa dipanggil langsung:

```bash
cd /path/to/clipper-project && python3 scripts/init_db.py
cd /path/to/clipper-project && python3 scripts/run_worker.sh
```

---

## Workflow n8n yang Direkomendasikan

### Workflow 1: Input Parser (Trigger Manual atau Cron)

```
[Trigger: Cron / Webhook]
        ↓
[Execute Command: parse jobs.md]
        ↓
[JSON Parse: ambil list job baru]
        ↓
[Loop: untuk setiap job]
        ↓
[Execute Command: insert_job ke SQLite]
        ↓
[Telegram: kirim notifikasi "Job X dibuat"]
```

### Workflow 2: LLM Generate Plan

```
[Trigger: DB polling - job status = 'ready']
        ↓
[Execute Command: ambil job dari queue]
        ↓
[Execute Command: panggil ollama_client.generate_highlight_plan()]
        ↓
[Execute Command: simpan hasil plan ke notes / metadata]
        ↓
[Execute Command: update job status → 'queued']
```

### Workflow 3: Render Video

```
[Trigger: DB polling - job status = 'queued']
        ↓
[Execute Command: update status → 'rendering']
        ↓
[Execute Command: ffmpeg_renderer.render_job()]
        ↓
[IF: render berhasil?]
    YES → [Execute Command: update status → 'ready_to_upload']
    NO  → [Execute Command: mark_failed()]
           → [Telegram: kirim notifikasi error]
```

### Workflow 4: Upload YouTube

```
[Trigger: Cron - jam tertentu (06:00, 10:00, dst.)]
        ↓
[Execute Command: pick_next_job_for_upload()]
        ↓
[IF: ada job?]
    YES → [Execute Command: youtube_uploader.upload_video()]
           → [Execute Command: mark_done()]
           → [Telegram: "Video X berhasil diupload"]
    NO  → [Stop]
```

---

## Contoh Script Python Siap Pakai untuk n8n

Simpan script-script ini di `scripts/n8n/` untuk dipanggil langsung.

### scripts/n8n/parse_inbox.py
```python
#!/usr/bin/env python3
import sys, json
sys.path.insert(0, str(__import__('pathlib').Path(__file__).parent.parent.parent))

from src.parser.md_parser import parse_inbox_dir
from src.queue.queue_manager import insert_job

jobs = parse_inbox_dir('input/inbox')
result = []
for j in jobs:
    jid = insert_job(
        source_url=j.source_url, prompt=j.prompt, caption=j.caption,
        schedule_times=j.schedule_times, shorts_count=j.shorts_count,
        status=j.status, input_source='inbox',
    )
    result.append({'job_id': jid, 'status': j.status})

print(json.dumps(result))
```

### scripts/n8n/get_ready_jobs.py
```python
#!/usr/bin/env python3
import sys, json
sys.path.insert(0, str(__import__('pathlib').Path(__file__).parent.parent.parent))

from src.queue.queue_manager import list_jobs_by_status

jobs = list_jobs_by_status('ready')
print(json.dumps([{
    'id': j['id'],
    'source_url': j['source_url'],
    'prompt': j['prompt'],
    'shorts_count': j['shorts_count'],
    'schedule_times': j['schedule_times'],
} for j in jobs]))
```

### scripts/n8n/generate_plan.py
```python
#!/usr/bin/env python3
import sys, json
sys.path.insert(0, str(__import__('pathlib').Path(__file__).parent.parent.parent))

job_id = sys.argv[1] if len(sys.argv) > 1 else ''
if not job_id:
    print(json.dumps({'error': 'job_id diperlukan'}))
    sys.exit(1)

from src.queue.queue_manager import get_job, update_job, move_job_status
from src.llm.ollama_client import generate_highlight_plan

job = get_job(job_id)
if not job:
    print(json.dumps({'error': f'Job {job_id} tidak ditemukan'}))
    sys.exit(1)

try:
    plan = generate_highlight_plan(
        source_url=job['source_url'],
        prompt_instructions=job['prompt'],
        shorts_count=job['shorts_count'],
    )
    update_job(job_id, notes=plan)
    move_job_status(job_id, 'queued')
    print(json.dumps({'job_id': job_id, 'status': 'queued', 'plan_length': len(plan)}))
except Exception as e:
    from src.queue.queue_manager import mark_failed
    mark_failed(job_id, str(e))
    print(json.dumps({'error': str(e)}))
    sys.exit(1)
```

### scripts/n8n/queue_status.py
```python
#!/usr/bin/env python3
import sys, json
sys.path.insert(0, str(__import__('pathlib').Path(__file__).parent.parent.parent))

from src.queue.queue_manager import count_jobs_by_status
print(json.dumps(count_jobs_by_status()))
```

---

## Integrasi Telegram → n8n

Jika ingin memproses command Telegram langsung dari n8n (tanpa menjalankan bot Python):

### Di n8n:
1. Tambahkan **Telegram Trigger** node
2. Tangkap teks pesan
3. Kirim ke script Python via Execute Command:

```bash
cd /path/to/clipper-project && python3 -c "
import sys, json
sys.path.insert(0, '.')
from src.bot.telegram_bot import handle_command

text = sys.argv[1]
responses = handle_command(text)
print(json.dumps({'responses': responses}))
" -- '{{ $json.message.text }}'
```

4. Parse JSON response
5. Kirim response ke Telegram via **Telegram node**

Dengan cara ini, logic bot sepenuhnya di Python, tapi koneksi Telegram dikelola n8n.

---

## Variabel n8n yang Berguna

Di n8n, set environment variable ini di Settings > Environment Variables:

```
CLIPPER_DIR=/path/to/clipper-project
PYTHON_BIN=/usr/bin/python3
```

Lalu di Execute Command node:
```bash
cd $CLIPPER_DIR && $PYTHON_BIN scripts/n8n/get_ready_jobs.py
```

---

## Tips Integrasi

1. **Selalu gunakan JSON output** — script Python harus `print(json.dumps(...))` agar n8n bisa parse
2. **Pisahkan workflow per fase** — satu workflow untuk parse input, satu untuk render, satu untuk upload
3. **Gunakan Cron trigger** untuk scheduler, bukan loop tak terbatas
4. **Error handling** — tangkap exit code dari Execute Command node (exit 0 = sukses, exit 1 = error)
5. **Polling status** — n8n bisa polling database setiap N menit untuk cek status job
6. **Concurrent rendering aman** — ffmpeg_renderer sudah dirancang tidak paralel, aman dipanggil berkali-kali
