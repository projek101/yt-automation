# Penjelasan Proyek — clipper-video-otomatis

## Apa Ini?

**clipper-video-otomatis** adalah kumpulan helper script Python 3 yang dirancang untuk bekerja bersama **n8n** sebagai sistem otomatisasi pembuatan video shorts dari video YouTube.

Proyek ini **bukan** aplikasi mandiri. Ia adalah "mesin di balik layar" yang dipanggil oleh n8n untuk melakukan pekerjaan berat: parsing input, manajemen antrean, pemanggilan LLM, pemrosesan video, dan penjadwalan upload.

---

## Mengapa Dibuat?

Membuat video shorts dari konten YouTube membutuhkan langkah yang panjang:

1. Menentukan mana bagian video yang menarik
2. Memotong bagian-bagian itu
3. Menggabungkan potongan menjadi satu short
4. Mengubah format ke portrait 9:16
5. Menambahkan logo dan teks
6. Mengupload ke YouTube pada jam yang tepat

Semua langkah ini bisa diotomatisasi — tetapi memerlukan koordinasi antara banyak sistem (Telegram, Ollama, FFmpeg, YouTube). Proyek ini menyediakan semua "komponen" itu, dan n8n yang mengatur kapan dan bagaimana komponen tersebut dipanggil.

---

## Arsitektur Umum

```
┌─────────────────────────────────────────────────────────────────┐
│                        n8n (Orkestrator)                        │
│  Workflow: trigger → execute script → polling → next step       │
└────────────────────┬────────────────────────────────────────────┘
                     │ memanggil via shell / webhook
                     ▼
┌─────────────────────────────────────────────────────────────────┐
│              clipper-video-otomatis (Helper Project)            │
│                                                                 │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ Input Parser │  │ Queue (SQLite│  │  Ollama LLM Client   │  │
│  │ .md / Telegram│ │  queue_mgr)  │  │  generate_plan()     │  │
│  └──────┬───────┘  └──────┬───────┘  └──────────┬───────────┘  │
│         │                 │                      │              │
│         └────────────────►│◄─────────────────────┘             │
│                           │                                     │
│              ┌────────────▼───────────┐                         │
│              │   FFmpeg Renderer      │                         │
│              │   cut → merge → crop  │                         │
│              │   overlay → export    │                         │
│              └────────────┬───────────┘                         │
│                           │                                     │
│              ┌────────────▼───────────┐                         │
│              │  Scheduler Manager    │                         │
│              │  (pilih waktu upload) │                         │
│              └────────────┬───────────┘                         │
│                           │                                     │
│              ┌────────────▼───────────┐                         │
│              │  YouTube Uploader     │                         │
│              │  (stub / OAuth2)      │                         │
│              └───────────────────────┘                         │
└─────────────────────────────────────────────────────────────────┘
         ▲                        ▲
         │ command Telegram       │ notifikasi status
┌────────┴────────┐    ┌─────────┴────────┐
│  Telegram Bot   │    │  Telegram Bot    │
│  (input user)   │    │  (output status) │
└─────────────────┘    └──────────────────┘
```

---

## Komponen Utama

### 1. Input Parser (`src/parser/`)
Menerima instruksi dari dua sumber:
- **File Markdown** (`input/jobs.md`, `input/inbox/*.md`): format terstruktur untuk batch job
- **Telegram Command** (`/clip`, `/attach_prompt`, dsb.): input realtime dari user

### 2. SQLite Queue (`src/queue/`)
Database ringan yang menyimpan semua job. Setiap job memiliki status yang bergerak dari `pending_prompt` → `ready` → `queued` → `rendering` → `ready_to_upload` → `scheduled` → `uploaded`.

Status juga bisa masuk ke `failed` jika ada error, lalu di-retry.

### 3. Ollama LLM Client (`src/llm/`)
Memanggil model bahasa lokal (Ollama) untuk:
- Menganalisis prompt user
- Membuat rencana highlight (timestamp mana yang dipotong)
- Membuat judul, caption, dan teks overlay

Output dari Ollama menggunakan format terstruktur yang bisa langsung diparse oleh sistem.

### 4. FFmpeg Video Processing (`src/video/`)
Dua lapisan:
- `ffmpeg_commands.py`: Builder — hanya membuat perintah (list string), tidak menjalankan apapun
- `ffmpeg_renderer.py`: Executor — menjalankan perintah satu per satu, aman untuk RAM terbatas

Pipeline per short:
```
raw video → cut segments → concat → crop portrait → overlay logo → text overlay → export mp4
```

### 5. YouTube Uploader Stub (`src/upload/`)
Siap dipakai dengan credential yang benar. Saat ini dalam mode stub (tidak upload sungguhan) karena memerlukan Google OAuth2 setup. Fungsi `build_metadata()` dan `validate_upload_payload()` sudah berfungsi penuh.

### 6. Telegram Bot (`src/bot/`)
Modul `handle_command()` bisa dipanggil langsung tanpa menjalankan bot (berguna untuk integrasi n8n via webhook). Jika bot dijalankan, mendukung polling real-time.

### 7. Scheduler (`src/scheduler/`)
Cek setiap 60 detik apakah ada job yang siap diupload sesuai jadwal. Mendukung pause/resume via Telegram.

---

## Status Job — Diagram Alur

```
         ┌─────────────────┐
         │  Input diterima  │
         └────────┬─────────┘
                  │
         ┌────────▼─────────┐
    ┌────│  pending_prompt  │  ← URL ada, prompt belum
    │    └──────────────────┘
    │             │ /attach_prompt
    │    ┌────────▼─────────┐
    └───►│      ready       │  ← URL + prompt lengkap
         └────────┬─────────┘
                  │ (oleh worker)
         ┌────────▼─────────┐
         │      queued      │  ← Masuk antrean
         └────────┬─────────┘
                  │
         ┌────────▼─────────┐
         │    rendering     │  ← FFmpeg berjalan
         └────────┬─────────┘
                  │
         ┌────────▼─────────┐
         │  ready_to_upload │  ← Video siap
         └────────┬─────────┘
                  │
         ┌────────▼─────────┐
         │    scheduled     │  ← Menunggu jam tertentu
         └────────┬─────────┘
                  │
         ┌────────▼─────────┐
         │     uploaded     │  ✓ Selesai
         └──────────────────┘

         ┌──────────────────┐
         │      failed      │  ✗ Error → bisa /retry
         └──────────────────┘
```

---

## Teknologi yang Digunakan

| Teknologi | Versi | Fungsi |
|-----------|-------|--------|
| Python | 3.10+ | Bahasa utama |
| SQLite | bawaan Python | Database antrean job |
| FFmpeg | sistem (apt/brew) | Pemrosesan video |
| Ollama | lokal | LLM untuk generate plan |
| python-telegram-bot | 20.x | Integrasi Telegram |
| requests | 2.31+ | HTTP client untuk Ollama |
| python-dotenv | 1.x | Load env variables |
| schedule | 1.2+ | Scheduling upload |

---

## Apa yang BUKAN bagian dari proyek ini

- Frontend / UI / web dashboard
- Runtime utama (itu tugas n8n)
- Download video dari YouTube (harus dilakukan sebelumnya, simpan ke `library/raw/`)
- Transkrip audio / speech-to-text
- Deteksi otomatis highlight tanpa prompt (perlu input manusia atau LLM)

---

## Asumsi Sistem

1. Video sumber sudah didownload dan tersimpan di `library/raw/`
2. FFmpeg sudah terinstal di sistem
3. Ollama sudah berjalan di `http://localhost:11434`
4. n8n sudah dikonfigurasi untuk memanggil script ini
5. Credential Telegram dan YouTube diisi di `.env`
